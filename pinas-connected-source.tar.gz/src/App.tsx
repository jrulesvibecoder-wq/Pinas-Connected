/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Radio, 
  Activity, 
  Calendar, 
  Send, 
  Terminal, 
  AlertTriangle, 
  CheckCircle2, 
  Plus, 
  Sliders, 
  ShieldAlert, 
  RefreshCw,
  TrendingDown,
  Layers,
  Zap,
  Smartphone,
  Wallet,
  Sparkles,
  Server,
  Trash2,
  Users,
  LifeBuoy
} from 'lucide-react';
import { Device, AlertLog, AppSettings, User as UserModel, Ticket } from './types';
import { Header } from './components/Header';
import { DeviceCard } from './components/DeviceCard';
import { DeviceModal } from './components/DeviceModal';
import { UispKeyModal } from './components/UispKeyModal';
import { TelegramSettingsModal } from './components/TelegramSettingsModal';
import { BillingManager } from './components/BillingManager';
import { TailscaleLinker } from './components/TailscaleLinker';
import { AlertLogDrawer } from './components/AlertLogDrawer';
import { TelegramPreviewModal } from './components/TelegramPreviewModal';
import { AdminPortal } from './components/AdminPortal';
import { InstallerSubscriptionModal } from './components/InstallerSubscriptionModal';
import { DockerDeployModal } from './components/DockerDeployModal';
import { AuthModal } from './components/AuthModal';
import { TicketManager } from './components/TicketManager';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'devices' | 'speed' | 'billing' | 'telegram' | 'tailscale' | 'tickets' | 'admin'>('devices');
  const [devices, setDevices] = useState<Device[]>([]);
  const [alerts, setAlerts] = useState<AlertLog[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [availableUsers, setAvailableUsers] = useState<any[]>([]);

  // Default User: Default Installer with 30-day trial
  const [currentUser, setCurrentUser] = useState<UserModel>({
    id: 'user-installer-1',
    email: 'installer@wisp.local',
    name: 'Juan Installer',
    companyName: 'SkyLink Wireless Solutions',
    phone: '+63 917 555 0192',
    role: 'installer',
    status: 'trial_active',
    trialEndsAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    createdAt: new Date().toISOString(),
    settings: {
      telegramToken: '',
      telegramChatId: '',
      globalSpeedThreshold: 5.0,
      alertsEnabled: true,
      billingAlertsEnabled: true,
      tailscaleFunnelUrl: 'https://ptp-monitor.tailscale.net',
      uispKeyToken: 'uisp_key_skylink_77a9',
      autoTicketingEnabled: true,
      autoTicketTimeoutMinutes: 5,
    },
  });

  const [settings, setSettings] = useState<AppSettings>({
    telegramToken: '',
    telegramChatId: '',
    globalSpeedThreshold: 5.0,
    alertsEnabled: true,
    billingAlertsEnabled: true,
    tailscaleFunnelUrl: 'https://ptp-monitor.tailscale.net',
    uispKeyToken: 'uisp_key_skylink_77a9',
    autoTicketingEnabled: true,
    autoTicketTimeoutMinutes: 5,
  });

  const [loading, setLoading] = useState<boolean>(true);
  const [isUispKeyModalOpen, setIsUispKeyModalOpen] = useState<boolean>(false);
  const [isTelegramModalOpen, setIsTelegramModalOpen] = useState<boolean>(false);
  const [isDeviceModalOpen, setIsDeviceModalOpen] = useState<boolean>(false);
  const [isAlertsDrawerOpen, setIsAlertsDrawerOpen] = useState<boolean>(false);
  const [isPhonePreviewOpen, setIsPhonePreviewOpen] = useState<boolean>(false);
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState<boolean>(false);
  const [isDockerModalOpen, setIsDockerModalOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [deviceToEdit, setDeviceToEdit] = useState<Device | null>(null);

  // Quick filter for topology on devices tab
  const [topologyFilter, setTopologyFilter] = useState<'all' | 'p2p' | 'ptmp'>('all');

  // Toast notification
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'alert' | 'info' } | null>(null);

  const showToast = (text: string, type: 'success' | 'alert' | 'info' = 'info') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 5000);
  };

  // Fetch initial data
  const fetchData = async () => {
    try {
      const installerParam = currentUser.role === 'admin' ? '' : `?installerId=${currentUser.id}`;
      const [devRes, alertRes, ticketRes, usersRes] = await Promise.all([
        fetch(`/api/devices${installerParam}`).then((r) => r.json()),
        fetch(`/api/alerts${installerParam}`).then((r) => r.json()),
        fetch(`/api/tickets${installerParam}`).then((r) => r.json()),
        fetch('/api/auth/users').then((r) => r.json()),
      ]);

      if (devRes.devices) setDevices(devRes.devices);
      if (alertRes.alerts) setAlerts(alertRes.alerts);
      if (ticketRes.tickets) setTickets(ticketRes.tickets);
      if (usersRes.users) {
        setAvailableUsers(usersRes.users);
        const matched = usersRes.users.find((u: any) => u.id === currentUser.id);
        if (matched) {
          setCurrentUser((prev) => ({
            ...prev,
            status: matched.status,
            expiresAt: matched.expiresAt,
            trialEndsAt: matched.trialEndsAt,
          }));
        }
      }
    } catch (e) {
      console.error('Error fetching data from API:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 8000);
    return () => clearInterval(interval);
  }, [currentUser.id]);

  // Update speed / simulation
  const handleUpdateSpeed = async (deviceId: string, throughput: number, capacity: number) => {
    try {
      const res = await fetch('/api/telemetry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          deviceId,
          throughput,
          capacity,
          key: settings.uispKeyToken,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setDevices((prev) =>
          prev.map((d) => (d.id === deviceId ? { ...d, ...data.device } : d))
        );
        const threshold = data.device.speedThreshold || settings.globalSpeedThreshold;
        if (throughput < threshold) {
          showToast(
            `🚨 Alert! ${data.device.name} dropped to ${throughput.toFixed(2)} Mbps (< ${threshold}M)`,
            'alert'
          );
        } else {
          showToast(`Updated ${data.device.name} to ${throughput.toFixed(2)} Mbps`, 'success');
        }
        fetchData();
      }
    } catch (err: any) {
      showToast(`Error updating speed: ${err.message}`, 'alert');
    }
  };

  // Save Settings
  const handleSaveSettings = async (newSettings: Partial<AppSettings>) => {
    try {
      const merged = { ...settings, ...newSettings };
      setSettings(merged);

      const res = await fetch('/api/auth/update-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          settings: merged,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('Settings saved successfully.', 'success');
      }
    } catch (e: any) {
      showToast(`Failed to save settings: ${e.message}`, 'alert');
    }
  };

  // Test Telegram Bot
  const handleSendTelegramTest = async (token: string, chatId: string) => {
    const res = await fetch('/api/telegram/test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, chatId, installerId: currentUser.id }),
    });
    const data = await res.json();
    fetchData();
    return data;
  };

  // Trigger manual test alert for device
  const handleTriggerTestAlert = async (device: Device) => {
    try {
      const res = await fetch('/api/telegram/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: settings.telegramToken,
          chatId: settings.telegramChatId,
          installerId: currentUser.id,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Telegram alert test dispatched for ${device.name}`, 'success');
      } else {
        showToast(`Telegram notification: ${data.error || 'Configure bot token'}`, 'alert');
      }
      fetchData();
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'alert');
    }
  };

  // Add / Edit Device
  const handleSaveDevice = async (deviceData: any) => {
    try {
      const payload = {
        ...deviceData,
        installerId: currentUser.id,
      };

      if (deviceToEdit) {
        const res = await fetch(`/api/devices/${deviceToEdit.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (data.success) {
          showToast(`Updated link ${deviceData.name}`, 'success');
          fetchData();
        }
      } else {
        const res = await fetch('/api/devices', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (data.success) {
          showToast(`Added new ${deviceData.topology.toUpperCase()} link ${deviceData.name}`, 'success');
          fetchData();
        }
      }
    } catch (err: any) {
      showToast(`Failed to save device: ${err.message}`, 'alert');
    }
  };

  // Delete Device
  const handleDeleteDevice = async (deviceId: string) => {
    if (!window.confirm('Are you sure you want to remove this wireless link?')) return;
    try {
      const res = await fetch(`/api/devices/${deviceId}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setDevices((prev) => prev.filter((d) => d.id !== deviceId));
        showToast('Link removed from monitor.', 'info');
      }
    } catch (err: any) {
      showToast(`Error deleting device: ${err.message}`, 'alert');
    }
  };

  // Clear all dummy links
  const handleClearAllDummies = async () => {
    if (!window.confirm('Clean all links? This will remove all dummy/sample devices so you can start with a clean slate.')) {
      return;
    }
    try {
      const res = await fetch('/api/devices/clear-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ installerId: currentUser.id }),
      });
      const data = await res.json();
      if (data.success) {
        setDevices([]);
        showToast('Cleaned all dummy links! System is ready for your real antennas.', 'success');
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'alert');
    }
  };

  // Load sample links (both P2P and PtMP)
  const handleLoadSamples = async () => {
    try {
      const res = await fetch('/api/devices/load-samples', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ installerId: currentUser.id }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Loaded ${data.count} realistic P2P & PtMP links!`, 'success');
        fetchData();
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'alert');
    }
  };

  // Send Billing Telegram Reminder
  const handleSendBillingTelegramReminder = async (deviceId?: string) => {
    const res = await fetch('/api/billing/send-reminder', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ installerId: currentUser.id, deviceId }),
    });
    const data = await res.json();
    fetchData();
    return data;
  };

  // Clear Alerts
  const handleClearAlerts = async () => {
    await fetch('/api/alerts', { method: 'DELETE' });
    setAlerts([]);
    showToast('Alert logs cleared.', 'info');
  };

  // Send simulated telemetry from Tailscale Linker
  const handleSendSimulatedTelemetry = async (payload: any) => {
    const res = await fetch('/api/telemetry', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...payload,
        key: settings.uispKeyToken,
      }),
    });
    const data = await res.json();
    fetchData();
    return data;
  };

  const degradedDevices = devices.filter(
    (d) => d.status === 'degraded' || d.throughput < (d.speedThreshold || settings.globalSpeedThreshold)
  );

  const displayedDevices = devices.filter((d) => {
    if (topologyFilter === 'p2p') return d.topology === 'p2p';
    if (topologyFilter === 'ptmp') return d.topology === 'ptmp';
    return true;
  });

  const openTicketsCount = tickets.filter((t) => t.status === 'open').length;

  return (
    <div className="min-h-screen bg-[#070D1E] text-gray-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-white">
      {/* Top Header */}
      <Header
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        devices={devices}
        alerts={alerts}
        settings={settings}
        currentUser={currentUser}
        openTicketCount={openTicketsCount}
        onOpenUispKey={() => setIsUispKeyModalOpen(true)}
        onOpenAddDevice={() => {
          setDeviceToEdit(null);
          setIsDeviceModalOpen(true);
        }}
        onOpenTelegramSettings={() => setIsTelegramModalOpen(true)}
        onOpenAlerts={() => setIsAlertsDrawerOpen(true)}
        onOpenDockerDeploy={() => setIsDockerModalOpen(true)}
        onOpenSubscriptionModal={() => setIsSubscriptionModalOpen(true)}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onClearAllDummies={handleClearAllDummies}
        onLoadSamples={handleLoadSamples}
      />

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 animate-in slide-in-from-bottom duration-200">
          <div
            className={`px-4 py-2.5 rounded-xl shadow-2xl text-xs font-semibold flex items-center space-x-2 border ${
              toastMessage.type === 'alert'
                ? 'bg-amber-950/90 border-amber-500 text-amber-200 shadow-amber-950/50'
                : toastMessage.type === 'success'
                ? 'bg-emerald-950/90 border-emerald-500 text-emerald-200 shadow-emerald-950/50'
                : 'bg-slate-900/90 border-cyan-500 text-cyan-200 shadow-cyan-950/50'
            }`}
          >
            {toastMessage.type === 'alert' ? (
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            )}
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* Main Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Quick System Status Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0F172A] border border-slate-800 rounded-xl p-3 text-xs">
          <div className="flex items-center space-x-3">
            <span className="flex items-center space-x-1.5 text-gray-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="font-semibold text-white">Monitoring:</span>
              <span className="text-emerald-400">Live (P2P + PtMP)</span>
            </span>
            <span className="text-gray-600">|</span>
            <span className="text-gray-300">
              Alert Trigger: <b className="text-amber-400">&lt; {settings.globalSpeedThreshold} Mbps</b>
            </span>
            <span className="hidden md:inline text-gray-600">|</span>
            <span className="hidden md:inline text-gray-300">
              Company: <b className="text-cyan-400">{currentUser.companyName}</b>
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setCurrentTab('tickets')}
              className="flex items-center space-x-1 text-rose-400 hover:text-white bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded-lg border border-slate-700 transition cursor-pointer"
            >
              <LifeBuoy className="w-3.5 h-3.5" />
              <span>Tickets ({openTicketsCount} Open)</span>
            </button>
            <button
              onClick={() => setIsPhonePreviewOpen(true)}
              className="flex items-center space-x-1 text-cyan-400 hover:text-white bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded-lg border border-slate-700 transition cursor-pointer"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Telegram Preview</span>
            </button>
            <button
              onClick={fetchData}
              className="p-1 rounded bg-slate-800 text-gray-400 hover:text-white transition cursor-pointer"
              title="Refresh Data"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Tab 1: P2P & PtMP Devices View (UISP Style) */}
        {currentTab === 'devices' && (
          <div className="space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h1 className="text-xl font-extrabold text-white tracking-tight flex items-center space-x-2">
                  <span>Wireless Links (P2P Backhauls & PtMP Sectors)</span>
                </h1>
                <p className="text-xs text-gray-400 mt-0.5">
                  Point-to-Point and Point-to-Multipoint links reporting via Tailscale Funnel. Alerts via Telegram if speed drops below {settings.globalSpeedThreshold} Mbps.
                </p>
              </div>

              <div className="flex items-center space-x-2">
                {/* Topology Filter Buttons */}
                <div className="flex items-center space-x-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
                  <button
                    onClick={() => setTopologyFilter('all')}
                    className={`px-2.5 py-1 rounded-lg font-semibold transition cursor-pointer ${
                      topologyFilter === 'all' ? 'bg-cyan-600 text-white' : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    All ({devices.length})
                  </button>
                  <button
                    onClick={() => setTopologyFilter('p2p')}
                    className={`px-2.5 py-1 rounded-lg font-semibold transition cursor-pointer ${
                      topologyFilter === 'p2p' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    P2P ({devices.filter((d) => d.topology === 'p2p').length})
                  </button>
                  <button
                    onClick={() => setTopologyFilter('ptmp')}
                    className={`px-2.5 py-1 rounded-lg font-semibold transition cursor-pointer ${
                      topologyFilter === 'ptmp' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    PtMP ({devices.filter((d) => d.topology === 'ptmp').length})
                  </button>
                </div>

                {devices.length === 0 && (
                  <button
                    onClick={handleLoadSamples}
                    className="bg-slate-800 hover:bg-slate-700 text-cyan-300 font-semibold text-xs px-3 py-2 rounded-lg border border-slate-700 transition flex items-center space-x-1.5 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Load Demo Links</span>
                  </button>
                )}

                <button
                  onClick={() => {
                    setDeviceToEdit(null);
                    setIsDeviceModalOpen(true);
                  }}
                  className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs px-3.5 py-2 rounded-lg transition shadow flex items-center space-x-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add P2P / PtMP Link</span>
                </button>
              </div>
            </div>

            {/* Empty State if no devices */}
            {displayedDevices.length === 0 ? (
              <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-12 text-center space-y-4 max-w-xl mx-auto shadow-2xl">
                <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mx-auto border border-cyan-500/20">
                  <Radio className="w-8 h-8 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white">Your Wireless Network is Ready</h3>
                  <p className="text-xs text-gray-400 mt-1 max-w-sm mx-auto">
                    No links found in this view. Connect your real Ubiquiti or Mikrotik CPEs using your Tailscale UISP Key, or add your first link.
                  </p>
                </div>
                <div className="flex items-center justify-center gap-3 pt-2">
                  <button
                    onClick={() => {
                      setDeviceToEdit(null);
                      setIsDeviceModalOpen(true);
                    }}
                    className="bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold px-4 py-2 rounded-lg transition shadow cursor-pointer flex items-center space-x-1"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add First Link</span>
                  </button>
                  <button
                    onClick={() => setCurrentTab('tailscale')}
                    className="bg-indigo-600/80 hover:bg-indigo-600 text-white text-xs font-semibold px-4 py-2 rounded-lg transition cursor-pointer flex items-center space-x-1"
                  >
                    <Terminal className="w-4 h-4" />
                    <span>Tailscale Linking</span>
                  </button>
                  <button
                    onClick={handleLoadSamples}
                    className="bg-slate-800 hover:bg-slate-700 text-gray-300 text-xs px-3 py-2 rounded-lg transition cursor-pointer"
                  >
                    Load Samples
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-5">
                {displayedDevices.map((device) => (
                  <DeviceCard
                    key={device.id}
                    device={device}
                    globalThreshold={settings.globalSpeedThreshold}
                    onUpdateSpeed={handleUpdateSpeed}
                    onEditDevice={(dev) => {
                      setDeviceToEdit(dev);
                      setIsDeviceModalOpen(true);
                    }}
                    onDeleteDevice={handleDeleteDevice}
                    onTriggerTestAlert={handleTriggerTestAlert}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Speed Drops (< 5 Mbps Alerts Monitor) */}
        {currentTab === 'speed' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-amber-950/40 to-slate-900 border border-amber-600/40 rounded-2xl p-6 shadow-xl space-y-4">
              <div className="flex items-center space-x-2 text-amber-400">
                <AlertTriangle className="w-5 h-5 text-amber-400" />
                <h2 className="text-lg font-bold text-white tracking-wide">
                  Bandwidth Drop Monitor (&lt; {settings.globalSpeedThreshold} Mbps Alerts)
                </h2>
              </div>
              <p className="text-xs text-gray-300 max-w-2xl leading-relaxed">
                This engine constantly monitors all client CPE throughputs. If any PTP link falls below your configured threshold, an instant message is dispatched to your Telegram via @BotFather.
              </p>

              {/* Threshold Adjuster Bar */}
              <div className="flex flex-wrap items-center gap-4 bg-slate-950/70 p-4 rounded-xl border border-slate-800">
                <div className="space-y-0.5">
                  <div className="text-[11px] uppercase tracking-wider text-gray-400 font-semibold">
                    GLOBAL SPEED ALERT THRESHOLD
                  </div>
                  <div className="text-xs text-gray-300">
                    Triggers Telegram Bot when link throughput drops below:
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    min="0.5"
                    max="100"
                    step="0.5"
                    value={settings.globalSpeedThreshold}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) || 1;
                      handleSaveSettings({ globalSpeedThreshold: val });
                    }}
                    className="w-24 bg-[#1F2937] border border-amber-500/60 rounded-lg px-3 py-1.5 text-white font-mono font-bold text-center focus:outline-none"
                  />
                  <span className="text-sm font-semibold text-amber-400">Mbps</span>
                </div>

                <div className="text-xs text-gray-400 flex items-center space-x-1.5 ml-auto">
                  <span>Currently Degraded:</span>
                  <span className="font-mono font-bold text-amber-400 text-sm">
                    {degradedDevices.length} of {devices.length} links
                  </span>
                </div>
              </div>
            </div>

            {/* Degraded Links Section */}
            <div className="space-y-3">
              <h3 className="font-bold text-sm text-white flex items-center space-x-2">
                <TrendingDown className="w-4 h-4 text-amber-400" />
                <span>Links Below Threshold ({degradedDevices.length})</span>
              </h3>

              {degradedDevices.length === 0 ? (
                <div className="bg-[#0F172A] border border-slate-800 rounded-xl p-8 text-center text-gray-400 space-y-2">
                  <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                  <p className="font-semibold text-white">All wireless links healthy!</p>
                  <p className="text-xs text-gray-500">
                    No connections are currently running below {settings.globalSpeedThreshold} Mbps.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {degradedDevices.map((device) => (
                    <DeviceCard
                      key={device.id}
                      device={device}
                      globalThreshold={settings.globalSpeedThreshold}
                      onUpdateSpeed={handleUpdateSpeed}
                      onEditDevice={(dev) => {
                        setDeviceToEdit(dev);
                        setIsDeviceModalOpen(true);
                      }}
                      onDeleteDevice={handleDeleteDevice}
                      onTriggerTestAlert={handleTriggerTestAlert}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 3: Client Due Date Calendar & Billing */}
        {currentTab === 'billing' && (
          <BillingManager
            devices={devices}
            onUpdateDevice={async (id, updates) => {
              await fetch(`/api/devices/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updates),
              });
              fetchData();
            }}
            onSendBillingTelegramReminder={handleSendBillingTelegramReminder}
          />
        )}

        {/* Tab 4: Support Tickets & Inactive Link Watchdog */}
        {currentTab === 'tickets' && (
          <TicketManager
            installerId={currentUser.id}
            devices={devices}
            settings={settings}
            onUpdateSettings={handleSaveSettings}
            showToast={showToast}
          />
        )}

        {/* Tab 5: Tailscale Linking Front-End */}
        {currentTab === 'tailscale' && (
          <TailscaleLinker
            settings={settings}
            onUpdateSettings={handleSaveSettings}
            onSendSimulatedTelemetry={handleSendSimulatedTelemetry}
            showToast={showToast}
          />
        )}

        {/* Tab 6: Telegram Bot Setup (@BotFather) */}
        {currentTab === 'telegram' && (
          <div className="space-y-6">
            <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center space-x-2.5">
                  <Send className="w-6 h-6 text-sky-400" />
                  <div>
                    <h2 className="text-lg font-bold text-white tracking-wide">
                      Telegram Bot Automation Configuration
                    </h2>
                    <p className="text-xs text-gray-400">
                      Connect your bot created with @BotFather to receive instant speed drop, client ticket, & billing alerts.
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setIsPhonePreviewOpen(true)}
                  className="flex items-center space-x-1.5 bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold px-3.5 py-2 rounded-lg transition shadow cursor-pointer"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Preview Messages</span>
                </button>
              </div>

              {/* Bot status banner */}
              <div
                className={`p-4 rounded-xl border flex flex-wrap items-center justify-between gap-3 text-xs ${
                  settings.telegramToken && settings.telegramChatId
                    ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                    : 'bg-amber-950/40 border-amber-500/50 text-amber-300'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span
                    className={`w-2.5 h-2.5 rounded-full ${
                      settings.telegramToken && settings.telegramChatId
                        ? 'bg-emerald-400 animate-pulse'
                        : 'bg-amber-400'
                    }`}
                  />
                  <span className="font-semibold text-sm">
                    {settings.telegramToken && settings.telegramChatId
                      ? 'Telegram Bot Connected & Ready'
                      : 'Telegram Bot Not Fully Configured'}
                  </span>
                </div>

                <button
                  onClick={() => setIsTelegramModalOpen(true)}
                  className="bg-slate-800 hover:bg-slate-700 text-white px-3.5 py-1.5 rounded-lg border border-slate-700 text-xs font-medium cursor-pointer transition"
                >
                  Open Bot Settings
                </button>
              </div>

              {/* Guide cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800 space-y-2">
                  <h4 className="font-bold text-xs uppercase text-cyan-400 tracking-wider">
                    Alert 1: Low Bandwidth (&lt; 5 Mbps)
                  </h4>
                  <p className="text-xs text-gray-300">
                    Dispatched the instant a CPE reports throughput or link capacity below your threshold. Includes device name, client, signal RSSI, and TX power.
                  </p>
                </div>

                <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800 space-y-2">
                  <h4 className="font-bold text-xs uppercase text-rose-400 tracking-wider">
                    Alert 2: Support Tickets & Inactive Links
                  </h4>
                  <p className="text-xs text-gray-300">
                    Notifies technician immediately when a client files a ticket or when an antenna stops responding and triggers an auto-ticket.
                  </p>
                </div>

                <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800 space-y-2">
                  <h4 className="font-bold text-xs uppercase text-emerald-400 tracking-wider">
                    Alert 3: Billing Due Reminders
                  </h4>
                  <p className="text-xs text-gray-300">
                    Summarizes all clients due today, due in 3 days, or overdue. Can be triggered with one click or scheduled automatically.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 7: Admin Portal (Super Admin) */}
        {currentTab === 'admin' && (
          <AdminPortal
            currentUser={currentUser}
            onRefreshData={fetchData}
            showToast={showToast}
          />
        )}
      </main>

      {/* Modals & Drawers */}
      <UispKeyModal
        isOpen={isUispKeyModalOpen}
        onClose={() => setIsUispKeyModalOpen(false)}
        settings={settings}
        onUpdateSettings={handleSaveSettings}
      />

      <TelegramSettingsModal
        isOpen={isTelegramModalOpen}
        onClose={() => setIsTelegramModalOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
        onSendTestMessage={handleSendTelegramTest}
        onOpenPhonePreview={() => {
          setIsTelegramModalOpen(false);
          setIsPhonePreviewOpen(true);
        }}
      />

      <DeviceModal
        isOpen={isDeviceModalOpen}
        onClose={() => {
          setIsDeviceModalOpen(false);
          setDeviceToEdit(null);
        }}
        deviceToEdit={deviceToEdit}
        globalThreshold={settings.globalSpeedThreshold}
        existingDevices={devices}
        onSave={handleSaveDevice}
      />

      <AlertLogDrawer
        isOpen={isAlertsDrawerOpen}
        onClose={() => setIsAlertsDrawerOpen(false)}
        alerts={alerts}
        onClearAlerts={handleClearAlerts}
      />

      <TelegramPreviewModal
        isOpen={isPhonePreviewOpen}
        onClose={() => setIsPhonePreviewOpen(false)}
        devices={devices}
        settings={settings}
      />

      <InstallerSubscriptionModal
        isOpen={isSubscriptionModalOpen}
        onClose={() => setIsSubscriptionModalOpen(false)}
        currentUser={currentUser}
        onPaymentSubmitted={fetchData}
        showToast={showToast}
      />

      <DockerDeployModal
        isOpen={isDockerModalOpen}
        onClose={() => setIsDockerModalOpen(false)}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        availableUsers={availableUsers}
        currentUser={currentUser}
        onSelectUser={(u) => {
          setCurrentUser(u);
          if (u.settings) setSettings(u.settings);
        }}
        onUserRegistered={(u) => {
          setCurrentUser(u);
          if (u.settings) setSettings(u.settings);
          fetchData();
        }}
        showToast={showToast}
      />
    </div>
  );
}
