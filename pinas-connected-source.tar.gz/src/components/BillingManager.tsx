import React, { useState } from 'react';
import { 
  Calendar, 
  DollarSign, 
  Send, 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  Filter, 
  Search,
  MessageSquare,
  UserCheck,
  RefreshCw
} from 'lucide-react';
import { Device } from '../types';

interface BillingManagerProps {
  devices: Device[];
  onUpdateDevice: (deviceId: string, updates: Partial<Device>) => void;
  onSendBillingTelegramReminder: (deviceId?: string) => Promise<{ success: boolean; error?: string }>;
}

export const BillingManager: React.FC<BillingManagerProps> = ({
  devices,
  onUpdateDevice,
  onSendBillingTelegramReminder,
}) => {
  const [filter, setFilter] = useState<'all' | 'due_soon' | 'overdue' | 'paid'>('all');
  const [search, setSearch] = useState('');
  const [sendingReminder, setSendingReminder] = useState(false);
  const [reminderStatus, setReminderStatus] = useState<string | null>(null);

  // Compute current day of month
  const today = new Date().getDate();

  // Categorize clients
  const processedClients = devices.map((d) => {
    let dueState: 'overdue' | 'due_today' | 'due_soon' | 'normal' = 'normal';
    const dayDiff = d.billingDueDay - today;

    if (d.paymentStatus === 'overdue' || (d.paymentStatus === 'pending' && dayDiff < 0)) {
      dueState = 'overdue';
    } else if (d.paymentStatus === 'pending' && dayDiff === 0) {
      dueState = 'due_today';
    } else if (d.paymentStatus === 'pending' && dayDiff > 0 && dayDiff <= 4) {
      dueState = 'due_soon';
    }

    return {
      ...d,
      computedDueState: dueState,
      dayDiff,
    };
  });

  const filteredClients = processedClients.filter((client) => {
    const matchesSearch =
      client.clientName.toLowerCase().includes(search.toLowerCase()) ||
      client.name.toLowerCase().includes(search.toLowerCase()) ||
      client.ip.includes(search);

    if (!matchesSearch) return false;

    if (filter === 'due_soon') {
      return client.computedDueState === 'due_soon' || client.computedDueState === 'due_today';
    }
    if (filter === 'overdue') {
      return client.computedDueState === 'overdue' || client.paymentStatus === 'overdue';
    }
    if (filter === 'paid') {
      return client.paymentStatus === 'paid';
    }
    return true;
  });

  const totalMonthly = devices.reduce((sum, d) => sum + (d.monthlyFee || 0), 0);
  const totalCollected = devices
    .filter((d) => d.paymentStatus === 'paid')
    .reduce((sum, d) => sum + (d.monthlyFee || 0), 0);
  const totalOutstanding = totalMonthly - totalCollected;

  const overdueCount = processedClients.filter((c) => c.computedDueState === 'overdue').length;
  const dueSoonCount = processedClients.filter(
    (c) => c.computedDueState === 'due_soon' || c.computedDueState === 'due_today'
  ).length;

  const handleSendReminder = async (deviceId?: string) => {
    setSendingReminder(true);
    setReminderStatus(null);
    try {
      const res = await onSendBillingTelegramReminder(deviceId);
      if (res.success) {
        setReminderStatus('✅ Reminder sent to your Telegram!');
      } else {
        setReminderStatus(`⚠️ ${res.error || 'Failed to send'}`);
      }
    } catch (err: any) {
      setReminderStatus(`⚠️ ${err.message || 'Error'}`);
    } finally {
      setSendingReminder(false);
      setTimeout(() => setReminderStatus(null), 4000);
    }
  };

  const handleTogglePayment = (client: Device) => {
    const nextStatus =
      client.paymentStatus === 'paid'
        ? 'pending'
        : client.paymentStatus === 'pending'
        ? 'paid'
        : 'paid';
    onUpdateDevice(client.id, { paymentStatus: nextStatus });
  };

  return (
    <div className="space-y-6">
      {/* Header & Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-[#0F172A] border border-slate-800 rounded-xl p-4 shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
              MONTHLY REVENUE
            </span>
            <DollarSign className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-extrabold font-mono text-white mt-1">
            ${totalMonthly.toFixed(2)}
          </div>
          <div className="text-xs text-gray-400 mt-1">
            Across {devices.length} active PTP clients
          </div>
        </div>

        <div className="bg-[#0F172A] border border-slate-800 rounded-xl p-4 shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
              PAID & COLLECTED
            </span>
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-extrabold font-mono text-emerald-400 mt-1">
            ${totalCollected.toFixed(2)}
          </div>
          <div className="text-xs text-gray-400 mt-1">
            {devices.filter((d) => d.paymentStatus === 'paid').length} clients settled
          </div>
        </div>

        <div className="bg-[#0F172A] border border-slate-800 rounded-xl p-4 shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
              OUTSTANDING / DUE
            </span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-extrabold font-mono text-amber-400 mt-1">
            ${totalOutstanding.toFixed(2)}
          </div>
          <div className="text-xs text-amber-300/80 mt-1">
            {overdueCount} overdue, {dueSoonCount} due soon
          </div>
        </div>
      </div>

      {/* Main Billing Table & Toolbar */}
      <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-white tracking-wide">Client Due Date Tracker</h2>
          </div>

          {/* Action to dispatch Telegram billing summary */}
          <div className="flex items-center space-x-2">
            {reminderStatus && (
              <span className="text-xs font-mono text-cyan-300 bg-cyan-950/80 px-2.5 py-1 rounded border border-cyan-800">
                {reminderStatus}
              </span>
            )}
            <button
              onClick={() => handleSendReminder()}
              disabled={sendingReminder}
              className="flex items-center space-x-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white text-xs font-semibold px-3.5 py-2 rounded-lg shadow cursor-pointer transition"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{sendingReminder ? 'Sending...' : 'Send Due Summary to Telegram'}</span>
            </button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          {/* Filters */}
          <div className="flex items-center space-x-1.5 bg-slate-900 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1 rounded-md transition cursor-pointer ${
                filter === 'all' ? 'bg-cyan-600 text-white font-medium' : 'text-gray-400 hover:text-white'
              }`}
            >
              All Clients ({devices.length})
            </button>
            <button
              onClick={() => setFilter('due_soon')}
              className={`px-3 py-1 rounded-md transition cursor-pointer ${
                filter === 'due_soon' ? 'bg-amber-600 text-white font-medium' : 'text-gray-400 hover:text-white'
              }`}
            >
              Due Soon ({dueSoonCount})
            </button>
            <button
              onClick={() => setFilter('overdue')}
              className={`px-3 py-1 rounded-md transition cursor-pointer ${
                filter === 'overdue' ? 'bg-red-600 text-white font-medium' : 'text-gray-400 hover:text-white'
              }`}
            >
              Overdue ({overdueCount})
            </button>
            <button
              onClick={() => setFilter('paid')}
              className={`px-3 py-1 rounded-md transition cursor-pointer ${
                filter === 'paid' ? 'bg-emerald-600 text-white font-medium' : 'text-gray-400 hover:text-white'
              }`}
            >
              Paid
            </button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search client, link, or IP..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 w-56"
            />
          </div>
        </div>

        {/* Client Billing List */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-gray-300 border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-[11px] uppercase tracking-wider text-gray-400 font-semibold bg-slate-900/50">
                <th className="py-3 px-3">Client & Link</th>
                <th className="py-3 px-3">Plan & Fee</th>
                <th className="py-3 px-3">Due Day of Month</th>
                <th className="py-3 px-3">Payment Status</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredClients.map((client) => {
                const isOverdue =
                  client.computedDueState === 'overdue' || client.paymentStatus === 'overdue';
                const isDueToday = client.computedDueState === 'due_today';
                const isDueSoon = client.computedDueState === 'due_soon';

                return (
                  <tr
                    key={client.id}
                    className="hover:bg-slate-900/60 transition group"
                  >
                    <td className="py-3.5 px-3">
                      <div className="font-semibold text-white text-sm">{client.clientName}</div>
                      <div className="text-[11px] text-gray-400 flex items-center space-x-1.5 mt-0.5">
                        <span>{client.name}</span>
                        <span>•</span>
                        <code className="text-cyan-400 font-mono">{client.ip}</code>
                      </div>
                    </td>

                    <td className="py-3.5 px-3">
                      <div className="font-medium text-gray-200">{client.planName}</div>
                      <div className="font-mono text-emerald-400 font-bold mt-0.5">
                        ${client.monthlyFee.toFixed(2)} / month
                      </div>
                    </td>

                    <td className="py-3.5 px-3">
                      <div className="flex items-center space-x-1.5">
                        <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                        <span className="font-mono font-bold text-white text-sm">
                          Every {client.billingDueDay}th
                        </span>
                      </div>
                      <div className="text-[10px] text-gray-400 mt-0.5">
                        {isOverdue ? (
                          <span className="text-red-400 font-medium">⚠️ Overdue payment</span>
                        ) : isDueToday ? (
                          <span className="text-amber-400 font-medium">🔔 Due Today!</span>
                        ) : isDueSoon ? (
                          <span className="text-amber-300">Due in {client.dayDiff} days</span>
                        ) : (
                          <span>Current cycle</span>
                        )}
                      </div>
                    </td>

                    <td className="py-3.5 px-3">
                      <button
                        onClick={() => handleTogglePayment(client)}
                        className={`px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider transition cursor-pointer border ${
                          client.paymentStatus === 'paid'
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                            : client.paymentStatus === 'overdue'
                            ? 'bg-red-500/20 text-red-300 border-red-500/40 hover:bg-red-500/30'
                            : 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                        }`}
                        title="Click to toggle Paid/Pending"
                      >
                        {client.paymentStatus === 'paid'
                          ? '✓ Paid'
                          : client.paymentStatus === 'overdue'
                          ? '! Overdue'
                          : '⏳ Pending'}
                      </button>
                    </td>

                    <td className="py-3.5 px-3 text-right">
                      <div className="flex items-center justify-end space-x-1.5">
                        <button
                          onClick={() => handleSendReminder(client.id)}
                          className="px-2.5 py-1 bg-sky-950/70 hover:bg-sky-900 border border-sky-600/40 text-sky-300 rounded text-xs flex items-center space-x-1 cursor-pointer transition"
                          title="Send individual Telegram reminder"
                        >
                          <Send className="w-3 h-3" />
                          <span>Remind Bot</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
