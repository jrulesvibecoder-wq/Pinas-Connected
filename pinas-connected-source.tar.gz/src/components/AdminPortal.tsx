import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Users, 
  CreditCard, 
  QrCode, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Plus, 
  Trash2, 
  Edit3, 
  Building, 
  Calendar, 
  DollarSign, 
  AlertCircle,
  ExternalLink,
  Save,
  Check,
  Smartphone,
  Wallet
} from 'lucide-react';
import { User, PaymentSubmission, BankingPortalConfig, BankAccount, WalletAccount } from '../types';

interface AdminPortalProps {
  currentUser: User;
  onRefreshData: () => void;
  showToast: (text: string, type?: 'success' | 'alert' | 'info') => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({
  currentUser,
  onRefreshData,
  showToast,
}) => {
  const [activeAdminTab, setActiveAdminTab] = useState<'installers' | 'payments' | 'banking'>('installers');
  const [installers, setInstallers] = useState<any[]>([]);
  const [payments, setPayments] = useState<PaymentSubmission[]>([]);
  const [bankingConfig, setBankingConfig] = useState<BankingPortalConfig | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // New Bank Account Form State
  const [newBankName, setNewBankName] = useState('');
  const [newAccountName, setNewAccountName] = useState('');
  const [newAccountNumber, setNewAccountNumber] = useState('');
  const [newBankQrUrl, setNewBankQrUrl] = useState('');
  const [newBankInstructions, setNewBankInstructions] = useState('');

  // New Wallet Form State
  const [newWalletName, setNewWalletName] = useState('GCash / QRPh');
  const [newWalletAccName, setNewWalletAccName] = useState('');
  const [newWalletNumber, setNewWalletNumber] = useState('');
  const [newWalletQrUrl, setNewWalletQrUrl] = useState('');
  const [newWalletInstructions, setNewWalletInstructions] = useState('');

  const fetchAdminData = async () => {
    try {
      const [instRes, payRes, bankRes] = await Promise.all([
        fetch('/api/admin/installers').then((r) => r.json()),
        fetch('/api/admin/payments').then((r) => r.json()),
        fetch('/api/banking-portal').then((r) => r.json()),
      ]);

      if (instRes.installers) setInstallers(instRes.installers);
      if (payRes.payments) setPayments(payRes.payments);
      if (bankRes.bankingPortal) setBankingConfig(bankRes.bankingPortal);
    } catch (e) {
      console.error('Failed to load admin data:', e);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchAdminData();
  }, []);

  // Activate / Extend Installer +30 Days
  const handleActivateInstaller = async (installerId: string, days: number = 30) => {
    try {
      const res = await fetch(`/api/admin/installers/${installerId}/activate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ days }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Account extended +${days} days until ${new Date(data.newExpiresAt).toLocaleDateString()}`, 'success');
        fetchAdminData();
        onRefreshData();
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'alert');
    }
  };

  // Suspend / Toggle Installer
  const handleToggleStatus = async (installerId: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'suspended' ? 'active' : 'suspended';
    try {
      const res = await fetch(`/api/admin/installers/${installerId}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: nextStatus }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Status updated to ${nextStatus}`, 'info');
        fetchAdminData();
        onRefreshData();
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'alert');
    }
  };

  // Delete Installer
  const handleDeleteInstaller = async (installerId: string) => {
    if (!window.confirm('Are you sure you want to delete this installer account and their links?')) return;
    try {
      const res = await fetch(`/api/admin/installers/${installerId}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        showToast('Installer account removed.', 'info');
        fetchAdminData();
        onRefreshData();
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'alert');
    }
  };

  // Approve Payment Reference (+30 Days Activation)
  const handleApprovePayment = async (paymentId: string) => {
    try {
      const res = await fetch(`/api/admin/payments/${paymentId}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminNotes: 'Approved & Verified' }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Payment Approved! Installer activated +30 days.`, 'success');
        fetchAdminData();
        onRefreshData();
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'alert');
    }
  };

  // Reject Payment Reference
  const handleRejectPayment = async (paymentId: string) => {
    const reason = window.prompt('Enter rejection reason (e.g. Reference number not found in bank/wallet records):');
    if (reason === null) return;
    try {
      const res = await fetch(`/api/admin/payments/${paymentId}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminNotes: reason }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('Payment rejected.', 'info');
        fetchAdminData();
        onRefreshData();
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'alert');
    }
  };

  // Save Banking Portal Config
  const handleSaveBankingConfig = async (updatedConfig: BankingPortalConfig) => {
    try {
      const res = await fetch('/api/admin/banking-portal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedConfig),
      });
      const data = await res.json();
      if (data.success) {
        setBankingConfig(data.bankingPortal);
        showToast('Banking portal details updated!', 'success');
      }
    } catch (e: any) {
      showToast(`Error saving config: ${e.message}`, 'alert');
    }
  };

  // Add Bank Account
  const handleAddBankAccount = () => {
    if (!newBankName || !newAccountNumber) {
      showToast('Bank Name and Account Number are required', 'alert');
      return;
    }
    if (!bankingConfig) return;

    const newAcc: BankAccount = {
      id: `bank-${Date.now()}`,
      bankName: newBankName,
      accountName: newAccountName || 'PTP Pulse Admin',
      accountNumber: newAccountNumber,
      qrCodeUrl: newBankQrUrl,
      instructions: newBankInstructions,
      active: true,
    };

    const updated = {
      ...bankingConfig,
      bankAccounts: [...bankingConfig.bankAccounts, newAcc],
    };

    handleSaveBankingConfig(updated);
    setNewBankName('');
    setNewAccountName('');
    setNewAccountNumber('');
    setNewBankQrUrl('');
    setNewBankInstructions('');
  };

  // Add Wallet Account
  const handleAddWalletAccount = () => {
    if (!newWalletName || !newWalletNumber) {
      showToast('Wallet Name and Number/Address are required', 'alert');
      return;
    }
    if (!bankingConfig) return;

    const newWallet: WalletAccount = {
      id: `wallet-${Date.now()}`,
      walletName: newWalletName,
      accountName: newWalletAccName || 'PTP Pulse Admin',
      accountNumberOrAddress: newWalletNumber,
      qrCodeUrl: newWalletQrUrl,
      instructions: newWalletInstructions,
      active: true,
    };

    const updated = {
      ...bankingConfig,
      walletAccounts: [...bankingConfig.walletAccounts, newWallet],
    };

    handleSaveBankingConfig(updated);
    setNewWalletName('GCash / QRPh');
    setNewWalletAccName('');
    setNewWalletNumber('');
    setNewWalletQrUrl('');
    setNewWalletInstructions('');
  };

  const pendingPayments = payments.filter((p) => p.status === 'pending');

  return (
    <div className="space-y-6">
      {/* Admin Header Banner */}
      <div className="bg-gradient-to-r from-purple-950/70 via-slate-900 to-indigo-950/60 border border-purple-600/40 rounded-2xl p-6 shadow-xl space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-white tracking-wide flex items-center space-x-2">
                <span>Master Admin & Installer Management</span>
                <span className="bg-purple-500/20 text-purple-300 text-[10px] px-2 py-0.5 rounded-full border border-purple-500/40 uppercase font-mono">
                  Super Admin
                </span>
              </h2>
              <p className="text-xs text-gray-300">
                Activate installer accounts every 30 days, review wallet payment references, and configure banking portal QR codes.
              </p>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="flex items-center space-x-3">
            <div className="bg-slate-950/80 px-3.5 py-1.5 rounded-xl border border-slate-800 text-center">
              <div className="text-[10px] text-gray-400 font-semibold uppercase">Pending Payments</div>
              <div className="text-base font-extrabold text-amber-400 font-mono">
                {pendingPayments.length}
              </div>
            </div>
            <div className="bg-slate-950/80 px-3.5 py-1.5 rounded-xl border border-slate-800 text-center">
              <div className="text-[10px] text-gray-400 font-semibold uppercase">Total Installers</div>
              <div className="text-base font-extrabold text-cyan-400 font-mono">
                {installers.filter((i) => i.role === 'installer').length}
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center space-x-2 border-t border-purple-900/40 pt-4 mt-2">
          <button
            onClick={() => setActiveAdminTab('installers')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
              activeAdminTab === 'installers'
                ? 'bg-purple-600 text-white shadow'
                : 'text-gray-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Installers ({installers.filter((i) => i.role === 'installer').length})</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('payments')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
              activeAdminTab === 'payments'
                ? 'bg-purple-600 text-white shadow'
                : 'text-gray-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>Wallet Payment Reference Queue</span>
            {pendingPayments.length > 0 && (
              <span className="bg-amber-500 text-black font-mono font-bold text-[10px] px-1.5 py-0.2 rounded-full">
                {pendingPayments.length} Pending
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveAdminTab('banking')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
              activeAdminTab === 'banking'
                ? 'bg-purple-600 text-white shadow'
                : 'text-gray-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>Banking Portal & QR Config</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Installers Control */}
      {activeAdminTab === 'installers' && (
        <div className="space-y-4">
          <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-xl overflow-x-auto">
            <h3 className="font-bold text-sm text-white mb-3 flex items-center space-x-2">
              <Users className="w-4 h-4 text-purple-400" />
              <span>Registered Installers & Subscription Days</span>
            </h3>

            <table className="w-full text-left text-xs text-gray-300 border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-gray-400 uppercase text-[10px] tracking-wider bg-slate-900/50">
                  <th className="py-2.5 px-3">Installer / Company</th>
                  <th className="py-2.5 px-3">Email & Contact</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Valid Until</th>
                  <th className="py-2.5 px-3">Days Left</th>
                  <th className="py-2.5 px-3">Active Links</th>
                  <th className="py-2.5 px-3 text-right">Admin Action (+30 Days)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {installers.map((inst) => {
                  const isTrial = inst.status === 'trial_active';
                  const isPending = inst.status === 'payment_pending_review';
                  const isExpired = inst.isExpired || inst.status === 'expired';

                  return (
                    <tr key={inst.id} className="hover:bg-slate-800/30 transition">
                      <td className="py-3 px-3">
                        <div className="font-semibold text-white">{inst.name}</div>
                        <div className="text-[11px] text-cyan-400">{inst.companyName || 'Independent Installer'}</div>
                      </td>
                      <td className="py-3 px-3">
                        <div className="font-mono text-gray-300">{inst.email}</div>
                        {inst.phone && <div className="text-[11px] text-gray-500">{inst.phone}</div>}
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                            inst.role === 'admin'
                              ? 'bg-purple-950 text-purple-300 border border-purple-700'
                              : isPending
                              ? 'bg-amber-950 text-amber-300 border border-amber-600 animate-pulse'
                              : isTrial
                              ? 'bg-blue-950 text-blue-300 border border-blue-600'
                              : isExpired
                              ? 'bg-red-950 text-red-300 border border-red-600'
                              : 'bg-emerald-950 text-emerald-300 border border-emerald-600'
                          }`}
                        >
                          {inst.role === 'admin'
                            ? 'MASTER ADMIN'
                            : isPending
                            ? 'REVIEW PENDING'
                            : isTrial
                            ? '30-DAY TRIAL'
                            : isExpired
                            ? 'EXPIRED'
                            : 'ACTIVE'}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-mono text-[11px]">
                        {inst.role === 'admin' ? 'Lifetime' : new Date(inst.expiresAt).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-3 font-mono font-bold">
                        {inst.role === 'admin' ? (
                          <span className="text-purple-400">∞</span>
                        ) : (
                          <span
                            className={
                              inst.daysLeft <= 3
                                ? 'text-red-400'
                                : inst.daysLeft <= 7
                                ? 'text-amber-400'
                                : 'text-emerald-400'
                            }
                          >
                            {inst.daysLeft} Days
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3 font-mono">
                        <span className="text-cyan-400 font-bold">{inst.deviceCount || 0}</span> PTP Links
                      </td>
                      <td className="py-3 px-3 text-right">
                        {inst.role !== 'admin' && (
                          <div className="flex items-center justify-end space-x-1.5">
                            <button
                              onClick={() => handleActivateInstaller(inst.id, 30)}
                              className="bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1 rounded text-[11px] font-medium transition cursor-pointer shadow flex items-center space-x-1"
                              title="Extend subscription by 30 days"
                            >
                              <Plus className="w-3 h-3" />
                              <span>+30 Days</span>
                            </button>

                            <button
                              onClick={() => handleToggleStatus(inst.id, inst.status)}
                              className="bg-slate-800 hover:bg-slate-700 text-gray-300 hover:text-white px-2 py-1 rounded text-[11px] transition cursor-pointer"
                              title={inst.status === 'suspended' ? 'Activate' : 'Suspend'}
                            >
                              {inst.status === 'suspended' ? 'Unsuspend' : 'Suspend'}
                            </button>

                            <button
                              onClick={() => handleDeleteInstaller(inst.id)}
                              className="text-gray-500 hover:text-red-400 p-1 transition cursor-pointer"
                              title="Delete installer account"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Payment Reference Review Queue */}
      {activeAdminTab === 'payments' && (
        <div className="space-y-4">
          <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-white flex items-center space-x-2">
                <CreditCard className="w-4 h-4 text-purple-400" />
                <span>Wallet Payment Reference Submissions</span>
              </h3>
              <span className="text-xs text-gray-400">
                Installers send payment via GCash/Maya/Bank and post Reference # here for verification
              </span>
            </div>

            {payments.length === 0 ? (
              <div className="text-center py-10 text-gray-500 space-y-2">
                <CheckCircle2 className="w-8 h-8 text-gray-600 mx-auto" />
                <p className="text-xs">No payment references submitted yet.</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-800">
                {payments.map((p) => (
                  <div key={p.id} className="py-4 flex flex-wrap items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            p.status === 'pending'
                              ? 'bg-amber-950 text-amber-300 border border-amber-600 animate-pulse'
                              : p.status === 'approved'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-600'
                              : 'bg-red-950 text-red-300 border border-red-600'
                          }`}
                        >
                          {p.status}
                        </span>
                        <span className="text-xs text-gray-400">
                          {new Date(p.submittedAt).toLocaleString()}
                        </span>
                      </div>

                      <div className="flex items-baseline space-x-2">
                        <span className="font-mono font-bold text-sm text-white">
                          Ref: <code className="bg-slate-900 px-1.5 py-0.5 rounded text-cyan-300 border border-slate-700">{p.referenceNumber}</code>
                        </span>
                        <span className="text-xs text-gray-400">via <b className="text-purple-300">{p.paymentMethod}</b></span>
                        <span className="text-xs font-mono font-bold text-emerald-400">
                          ${p.amount.toFixed(2)} {p.currency}
                        </span>
                      </div>

                      <div className="text-xs text-gray-300">
                        <span>Submitted by: <b>{p.installerName}</b> ({p.companyName}) • </span>
                        <span className="text-gray-400 font-mono">{p.installerEmail}</span>
                      </div>

                      {p.notes && (
                        <div className="text-[11px] text-gray-400 bg-slate-900/60 p-1.5 rounded border border-slate-800">
                          <b>Installer Note:</b> {p.notes}
                        </div>
                      )}

                      {p.adminNotes && (
                        <div className="text-[11px] text-purple-300">
                          <b>Admin Response:</b> {p.adminNotes}
                        </div>
                      )}
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center space-x-2">
                      {p.status === 'pending' ? (
                        <>
                          <button
                            onClick={() => handleApprovePayment(p.id)}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold shadow transition cursor-pointer flex items-center space-x-1"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Approve & Activate (+30 Days)</span>
                          </button>
                          <button
                            onClick={() => handleRejectPayment(p.id)}
                            className="bg-red-950/80 hover:bg-red-900 text-red-300 border border-red-700/60 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer"
                          >
                            Reject
                          </button>
                        </>
                      ) : (
                        <span className="text-xs text-gray-500 italic">Processed</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 3: Banking Portal & QR Config */}
      {activeAdminTab === 'banking' && bankingConfig && (
        <div className="space-y-6">
          {/* Price & Currency Config */}
          <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <h3 className="font-bold text-sm text-white flex items-center space-x-2">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span>Subscription Pricing Settings</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">
                  Monthly Subscription Fee (Every 30 Days)
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    min="1"
                    value={bankingConfig.monthlyPrice}
                    onChange={(e) =>
                      setBankingConfig({ ...bankingConfig, monthlyPrice: parseFloat(e.target.value) || 0 })
                    }
                    className="w-32 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono text-sm focus:outline-none"
                  />
                  <select
                    value={bankingConfig.currency}
                    onChange={(e) => setBankingConfig({ ...bankingConfig, currency: e.target.value })}
                    className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white text-xs"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="PHP">PHP (₱)</option>
                  </select>
                </div>
                <p className="text-[11px] text-gray-400 mt-1">
                  First 30 days are automatically free for all newly registered installers.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">
                  General Payment Instructions (Shown to Installers)
                </label>
                <textarea
                  rows={2}
                  value={bankingConfig.generalInstructions}
                  onChange={(e) =>
                    setBankingConfig({ ...bankingConfig, generalInstructions: e.target.value })
                  }
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white text-xs focus:outline-none"
                />
              </div>
            </div>

            <button
              onClick={() => handleSaveBankingConfig(bankingConfig)}
              className="bg-purple-600 hover:bg-purple-500 text-white px-3.5 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer shadow flex items-center space-x-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Pricing & Instructions</span>
            </button>
          </div>

          {/* Wallet Accounts (GCash / Maya / QRPh) */}
          <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <h3 className="font-bold text-sm text-white flex items-center space-x-2">
              <Wallet className="w-4 h-4 text-purple-400" />
              <span>E-Wallets & QR Payment Channels (GCash / Maya / QRPh / USDT)</span>
            </h3>

            {/* List Existing Wallets */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {bankingConfig.walletAccounts.map((w, idx) => (
                <div key={w.id} className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-2 relative">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-purple-300 flex items-center space-x-1.5">
                      <QrCode className="w-4 h-4 text-purple-400" />
                      <span>{w.walletName}</span>
                    </span>
                    <button
                      onClick={() => {
                        const updated = {
                          ...bankingConfig,
                          walletAccounts: bankingConfig.walletAccounts.filter((_, i) => i !== idx),
                        };
                        handleSaveBankingConfig(updated);
                      }}
                      className="text-gray-500 hover:text-red-400 p-1 transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="text-xs space-y-0.5">
                    <div>Account Name: <b className="text-white">{w.accountName}</b></div>
                    <div>
                      Number / Address:{' '}
                      <code className="bg-slate-950 px-1.5 py-0.5 rounded text-cyan-300 font-mono">
                        {w.accountNumberOrAddress}
                      </code>
                    </div>
                  </div>

                  {w.qrCodeUrl && (
                    <div className="mt-2 p-2 bg-white rounded-lg inline-block">
                      <img src={w.qrCodeUrl} alt="QR Code" className="w-24 h-24 object-contain" />
                    </div>
                  )}

                  {w.instructions && (
                    <p className="text-[11px] text-gray-400 italic">{w.instructions}</p>
                  )}
                </div>
              ))}
            </div>

            {/* Add New Wallet Box */}
            <div className="bg-slate-950/60 border border-dashed border-slate-700 rounded-xl p-4 space-y-3">
              <h4 className="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center space-x-1.5">
                <Plus className="w-3.5 h-3.5 text-purple-400" />
                <span>Add Wallet / QR Channel</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block text-gray-400 mb-1">Wallet Type</label>
                  <select
                    value={newWalletName}
                    onChange={(e) => setNewWalletName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                  >
                    <option value="GCash / QRPh">GCash / QRPh</option>
                    <option value="Maya / PayMaya">Maya / PayMaya</option>
                    <option value="QRPh Universal QR">QRPh Universal QR</option>
                    <option value="USDT (TRC-20)">USDT (TRC-20)</option>
                    <option value="PayPal">PayPal</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-400 mb-1">Account Holder Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Juan Dela Cruz"
                    value={newWalletAccName}
                    onChange={(e) => setNewWalletAccName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>

                <div>
                  <label className="block text-gray-400 mb-1">Mobile Number or Address</label>
                  <input
                    type="text"
                    placeholder="e.g. 0917-123-4567 or Wallet Address"
                    value={newWalletNumber}
                    onChange={(e) => setNewWalletNumber(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-gray-400 mb-1">QR Code Image URL (or upload data URL)</label>
                  <input
                    type="text"
                    placeholder="https://... or data:image/png;base64,..."
                    value={newWalletQrUrl}
                    onChange={(e) => setNewWalletQrUrl(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-gray-400 mb-1">Instructions</label>
                  <input
                    type="text"
                    placeholder="e.g. Scan QR via GCash or Maya app"
                    value={newWalletInstructions}
                    onChange={(e) => setNewWalletInstructions(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>
              </div>

              <button
                onClick={handleAddWalletAccount}
                className="bg-purple-600 hover:bg-purple-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold shadow transition cursor-pointer flex items-center space-x-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Save New Wallet / QR</span>
              </button>
            </div>
          </div>

          {/* Bank Accounts */}
          <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <h3 className="font-bold text-sm text-white flex items-center space-x-2">
              <Building className="w-4 h-4 text-cyan-400" />
              <span>Direct Bank Accounts</span>
            </h3>

            {/* Existing Banks */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {bankingConfig.bankAccounts.map((b, idx) => (
                <div key={b.id} className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-cyan-300">{b.bankName}</span>
                    <button
                      onClick={() => {
                        const updated = {
                          ...bankingConfig,
                          bankAccounts: bankingConfig.bankAccounts.filter((_, i) => i !== idx),
                        };
                        handleSaveBankingConfig(updated);
                      }}
                      className="text-gray-500 hover:text-red-400 p-1 transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="text-xs space-y-0.5">
                    <div>Account Name: <b className="text-white">{b.accountName}</b></div>
                    <div>Account #: <code className="bg-slate-950 px-1.5 py-0.5 rounded text-cyan-300 font-mono">{b.accountNumber}</code></div>
                  </div>
                  {b.instructions && <p className="text-[11px] text-gray-400">{b.instructions}</p>}
                </div>
              ))}
            </div>

            {/* Add Bank Form */}
            <div className="bg-slate-950/60 border border-dashed border-slate-700 rounded-xl p-4 space-y-3">
              <h4 className="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center space-x-1.5">
                <Plus className="w-3.5 h-3.5 text-cyan-400" />
                <span>Add Bank Account</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block text-gray-400 mb-1">Bank Name</label>
                  <input
                    type="text"
                    placeholder="e.g. BDO / UnionBank / BPI"
                    value={newBankName}
                    onChange={(e) => setNewBankName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-gray-400 mb-1">Account Name</label>
                  <input
                    type="text"
                    placeholder="e.g. PTP Pulse Admin"
                    value={newAccountName}
                    onChange={(e) => setNewAccountName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-gray-400 mb-1">Account Number</label>
                  <input
                    type="text"
                    placeholder="e.g. 0012-3456-7890"
                    value={newAccountNumber}
                    onChange={(e) => setNewAccountNumber(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>
              </div>

              <button
                onClick={handleAddBankAccount}
                className="bg-cyan-600 hover:bg-cyan-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold shadow transition cursor-pointer flex items-center space-x-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Bank Account</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
