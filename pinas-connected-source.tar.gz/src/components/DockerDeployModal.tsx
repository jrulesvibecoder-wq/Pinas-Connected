import React, { useState } from 'react';
import { 
  X, 
  Terminal, 
  Copy, 
  Check, 
  Layers, 
  Server, 
  ShieldCheck, 
  CheckCircle2, 
  ExternalLink 
} from 'lucide-react';

interface DockerDeployModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DockerDeployModal: React.FC<DockerDeployModalProps> = ({ isOpen, onClose }) => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(id);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const dockerComposeCmd = `# 1. Clone repository & navigate:
git clone https://github.com/your-username/ptp-linkpulse.git
cd ptp-linkpulse

# 2. Launch in background (Persistent data stored in ptp_data volume):
docker compose up -d --build

# 3. Check container logs:
docker compose logs -f`;

  const singleDockerRunCmd = `# Run anywhere with one command (Lightweight Alpine container < 60MB):
docker build -t ptp-linkpulse .
docker run -d \\
  --name ptp-monitor \\
  -p 3000:3000 \\
  -v ptp_data:/app/data \\
  --restart unless-stopped \\
  ptp-linkpulse`;

  const tailscaleFunnelDoc = `# Expose container port 3000 directly via Tailscale Funnel:
tailscale funnel 3000`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-[#0F172A] border border-cyan-700/40 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-[#1E293B] px-6 py-4 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white tracking-wide">
                Docker 1-Step Production Deployment
              </h3>
              <p className="text-xs text-gray-400">
                Ultra-lightweight replacement for UISP (runs smoothly on $5/mo VPS or Raspberry Pi)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-slate-700 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-gray-300">
          {/* Quick Specs Banner */}
          <div className="grid grid-cols-3 gap-3 bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 text-center">
            <div>
              <div className="text-[10px] text-gray-500 uppercase font-bold">RAM Usage</div>
              <div className="text-sm font-bold font-mono text-emerald-400">&lt; 65 MB</div>
              <div className="text-[10px] text-gray-400">vs 4GB official UISP</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase font-bold">Persistence</div>
              <div className="text-sm font-bold font-mono text-cyan-400">ptp_data volume</div>
              <div className="text-[10px] text-gray-400">Never loses data</div>
            </div>
            <div>
              <div className="text-[10px] text-gray-500 uppercase font-bold">Port</div>
              <div className="text-sm font-bold font-mono text-purple-400">3000 (HTTP/S)</div>
              <div className="text-[10px] text-gray-400">Tailscale Funnel ready</div>
            </div>
          </div>

          {/* Option 1: Docker Compose */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Option 1: Deploy with Docker Compose (Recommended)</span>
              </span>
              <button
                onClick={() => copyToClipboard(dockerComposeCmd, 'compose')}
                className="text-cyan-400 hover:text-cyan-300 flex items-center space-x-1 bg-slate-800 px-2 py-0.5 rounded cursor-pointer"
              >
                {copiedSection === 'compose' ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>

            <pre className="bg-[#050B14] p-3.5 rounded-xl font-mono text-gray-200 border border-slate-800 overflow-x-auto leading-relaxed">
              {dockerComposeCmd}
            </pre>
          </div>

          {/* Option 2: Standalone Docker Run */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
                <Terminal className="w-3.5 h-3.5 text-purple-400" />
                <span>Option 2: Standalone Docker Run Command</span>
              </span>
              <button
                onClick={() => copyToClipboard(singleDockerRunCmd, 'docker-run')}
                className="text-cyan-400 hover:text-cyan-300 flex items-center space-x-1 bg-slate-800 px-2 py-0.5 rounded cursor-pointer"
              >
                {copiedSection === 'docker-run' ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>

            <pre className="bg-[#050B14] p-3.5 rounded-xl font-mono text-gray-200 border border-slate-800 overflow-x-auto leading-relaxed">
              {singleDockerRunCmd}
            </pre>
          </div>

          {/* Step 3: Link with Tailscale Funnel */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                <span>Expose via Tailscale Funnel</span>
              </span>
              <button
                onClick={() => copyToClipboard(tailscaleFunnelDoc, 'funnel')}
                className="text-cyan-400 hover:text-cyan-300 flex items-center space-x-1 bg-slate-800 px-2 py-0.5 rounded cursor-pointer"
              >
                {copiedSection === 'funnel' ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>

            <pre className="bg-[#050B14] p-3.5 rounded-xl font-mono text-gray-200 border border-slate-800 overflow-x-auto leading-relaxed">
              {tailscaleFunnelDoc}
            </pre>
          </div>

          {/* Download Full Source Archive */}
          <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
            <div>
              <div className="font-bold text-white text-xs">Download Full Source Code (.tar.gz)</div>
              <div className="text-[11px] text-gray-400">Keep an offline backup or upload manually to GitHub</div>
            </div>
            <a
              href="/api/download-source"
              download="pinas-connected-source.tar.gz"
              className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs px-3.5 py-2 rounded-lg transition shadow flex items-center space-x-1.5"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Download Archive</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
