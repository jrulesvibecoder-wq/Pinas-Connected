import React, { useState } from 'react';
import { 
  Send, 
  X, 
  Check, 
  AlertCircle, 
  ExternalLink, 
  Info, 
  Bot, 
  ShieldCheck, 
  HelpCircle,
  Smartphone
} from 'lucide-react';
import { AppSettings } from '../types';

interface TelegramSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSaveSettings: (newSettings: Partial<AppSettings>) => void;
  onSendTestMessage: (token: string, chatId: string) => Promise<{ success: boolean; error?: string }>;
  onOpenPhonePreview: () => void;
}

export const TelegramSettingsModal: React.FC<TelegramSettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  onSendTestMessage,
  onOpenPhonePreview,
}) => {
  if (!isOpen) return null;

  const [token, setToken] = useState(settings.telegramToken || '');
  const [chatId, setChatId] = useState(settings.telegramChatId || '');
  const [threshold, setThreshold] = useState(settings.globalSpeedThreshold || 5.0);
  const [alertsEnabled, setAlertsEnabled] = useState(settings.alertsEnabled);
  const [billingAlertsEnabled, setBillingAlertsEnabled] = useState(settings.billingAlertsEnabled);

  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; error?: string } | null>(null);

  const handleTest = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await onSendTestMessage(token, chatId);
      setTestResult(res);
    } catch (err: any) {
      setTestResult({ success: false, error: err.message || 'Failed to send test message' });
    } finally {
      setIsTesting(false);
    }
  };

  const handleSave = () => {
    onSaveSettings({
      telegramToken: token,
      telegramChatId: chatId,
      globalSpeedThreshold: Number(threshold),
      alertsEnabled,
      billingAlertsEnabled,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-[#111827] border border-cyan-500/40 rounded-2xl shadow-2xl w-full max-w-xl text-gray-100 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-gradient-to-r from-sky-600 to-blue-700 px-6 py-4 flex items-center justify-between text-white">
          <div className="flex items-center space-x-2.5">
            <Bot className="w-5 h-5 text-sky-200" />
            <h2 className="font-bold text-base tracking-wide">Telegram Bot Setup (@BotFather)</h2>
          </div>
          <button
            onClick={onClose}
            className="text-sky-200 hover:text-white p-1 rounded-md transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Quick Guide on @BotFather */}
          <div className="bg-sky-950/40 border border-sky-800/40 rounded-xl p-4 text-xs space-y-2.5 text-sky-200">
            <div className="font-semibold text-white flex items-center justify-between">
              <span className="flex items-center space-x-1.5">
                <HelpCircle className="w-4 h-4 text-sky-400" />
                <span>How to create your Bot in 2 minutes:</span>
              </span>
              <button
                type="button"
                onClick={onOpenPhonePreview}
                className="text-cyan-300 hover:text-white flex items-center space-x-1 underline cursor-pointer"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Preview Telegram UI</span>
              </button>
            </div>
            <ol className="list-decimal list-inside space-y-1 text-gray-300">
              <li>
                Open Telegram and search for{' '}
                <a
                  href="https://t.me/BotFather"
                  target="_blank"
                  rel="noreferrer"
                  className="text-sky-400 font-mono hover:underline font-bold"
                >
                  @BotFather
                </a>
                .
              </li>
              <li>
                Send <code className="bg-gray-800 px-1.5 py-0.5 rounded text-amber-300">/newbot</code> and choose a name (e.g. <i>MyPtpAlertBot</i>).
              </li>
              <li>
                Copy the <b>HTTP API Token</b> (looks like <code>7123456789:AAH...</code>) and paste it below.
              </li>
              <li>
                Open your new bot and press <b>Start</b>. Then message{' '}
                <a
                  href="https://t.me/userinfobot"
                  target="_blank"
                  rel="noreferrer"
                  className="text-sky-400 font-mono hover:underline font-bold"
                >
                  @userinfobot
                </a>{' '}
                to get your numeric <b>Chat ID</b>.
              </li>
            </ol>
          </div>

          {/* Bot Token Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-gray-300 flex items-center justify-between">
              <span>TELEGRAM BOT TOKEN</span>
              <span className="text-[10px] text-gray-400">From @BotFather</span>
            </label>
            <input
              type="text"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              placeholder="e.g. 7123456789:AAH_XYZ1234567890abcdef"
              className="w-full bg-[#1F2937] border border-gray-700 rounded-lg px-3.5 py-2.5 text-sm font-mono text-cyan-300 focus:outline-none focus:border-cyan-500 placeholder-gray-500"
            />
          </div>

          {/* Chat ID Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-gray-300 flex items-center justify-between">
              <span>YOUR TELEGRAM CHAT ID</span>
              <span className="text-[10px] text-gray-400">Personal ID or Channel/Group ID</span>
            </label>
            <input
              type="text"
              value={chatId}
              onChange={(e) => setChatId(e.target.value)}
              placeholder="e.g. 102938475 or -1001234567890"
              className="w-full bg-[#1F2937] border border-gray-700 rounded-lg px-3.5 py-2.5 text-sm font-mono text-cyan-300 focus:outline-none focus:border-cyan-500 placeholder-gray-500"
            />
          </div>

          {/* Speed Threshold Settings */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-gray-800">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold uppercase tracking-wider text-gray-300">
                GLOBAL SPEED THRESHOLD
              </label>
              <div className="flex items-center space-x-2">
                <input
                  type="number"
                  min="0.5"
                  max="1000"
                  step="0.5"
                  value={threshold}
                  onChange={(e) => setThreshold(parseFloat(e.target.value) || 1)}
                  className="w-28 bg-[#1F2937] border border-gray-700 rounded-lg px-3 py-2 text-sm font-mono text-white text-center focus:outline-none focus:border-cyan-500"
                />
                <span className="text-sm font-medium text-cyan-400">Mbps</span>
              </div>
              <p className="text-[11px] text-gray-400">
                Alerts trigger if link throughput drops below this (default: <b>5.0 Mbps</b>).
              </p>
            </div>

            <div className="space-y-3">
              <label className="text-xs font-semibold uppercase tracking-wider text-gray-300">
                NOTIFICATION CHANNELS
              </label>
              <label className="flex items-center space-x-2 text-xs text-gray-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={alertsEnabled}
                  onChange={(e) => setAlertsEnabled(e.target.checked)}
                  className="rounded text-cyan-600 focus:ring-cyan-500"
                />
                <span>Bandwidth Drop Alerts (&lt; 5 Mbps)</span>
              </label>
              <label className="flex items-center space-x-2 text-xs text-gray-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={billingAlertsEnabled}
                  onChange={(e) => setBillingAlertsEnabled(e.target.checked)}
                  className="rounded text-cyan-600 focus:ring-cyan-500"
                />
                <span>Client Billing Due Reminders</span>
              </label>
            </div>
          </div>

          {/* Test Status Banner */}
          {testResult && (
            <div
              className={`p-3.5 rounded-xl border text-xs flex items-start space-x-2 ${
                testResult.success
                  ? 'bg-emerald-950/60 border-emerald-600/50 text-emerald-300'
                  : 'bg-red-950/60 border-red-600/50 text-red-300'
              }`}
            >
              {testResult.success ? (
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              )}
              <div>
                <div className="font-semibold">
                  {testResult.success ? 'Message Sent Successfully!' : 'Telegram Error'}
                </div>
                <div className="mt-0.5 text-gray-300 font-mono text-[11px]">
                  {testResult.success
                    ? 'Check your Telegram app. You should have received the PTP LinkPulse test ping.'
                    : testResult.error}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="bg-[#0B132B] px-6 py-4 flex flex-wrap items-center justify-between gap-3 border-t border-gray-800">
          <button
            type="button"
            onClick={handleTest}
            disabled={isTesting || !token || !chatId}
            className="flex items-center space-x-2 bg-sky-600 hover:bg-sky-500 disabled:bg-gray-800 disabled:text-gray-500 text-white px-4 py-2 rounded-lg text-xs font-semibold transition cursor-pointer shadow"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{isTesting ? 'Sending to Telegram...' : 'Send Test Alert to Telegram'}</span>
          </button>

          <div className="flex items-center space-x-2">
            <button
              onClick={onClose}
              className="px-3.5 py-2 text-xs text-gray-400 hover:text-white transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-semibold transition cursor-pointer shadow"
            >
              Save Bot Settings
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
