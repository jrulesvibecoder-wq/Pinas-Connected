import React, { useState, useEffect } from 'react';
import { 
  LifeBuoy, 
  Plus, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Trash2, 
  Zap, 
  Phone, 
  Radio, 
  Search, 
  Filter, 
  Sparkles,
  Layers,
  Check,
  Send,
  Sliders
} from 'lucide-react';
import { Ticket, Device, AppSettings } from '../types';
import { ClientTicketModal } from './ClientTicketModal';

interface TicketManagerProps {
  installerId: string;
  devices: Device[];
  settings: AppSettings;
  onUpdateSettings: (settings: Partial<AppSettings>) => Promise<void>;
  showToast: (text: string, type?: 'success' | 'alert' | 'info') => void;
}

export const TicketManager: React.FC<TicketManagerProps> = ({
  installerId,
  devices,
  settings,
  onUpdateSettings,
  showToast,
}) => {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filterStatus, setFilterStatus] = useState<'all' | 'open' | 'in_progress' | 'resolved' | 'auto'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isFilingModalOpen, setIsFilingModalOpen] = useState<boolean>(false);
  const [resolutionPromptId, setResolutionPromptId] = useState<string | null>(null);
  const [resolutionNote, setResolutionNote] = useState<string>('');

  // Auto-ticketing settings state
  const [autoTicketEnabled, setAutoTicketEnabled] = useState<boolean>(
    settings.autoTicketingEnabled !== false
  );
  const [timeoutMinutes, setTimeoutMinutes] = useState<number>(
    settings.autoTicketTimeoutMinutes || 5
  );

  const fetchTickets = async () => {
    try {
      const res = await fetch(`/api/tickets?installerId=${installerId}`);
      const data = await res.json();
      if (data.tickets) setTickets(data.tickets);
    } catch (e) {
      console.error('Error loading tickets:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
    const interval = setInterval(fetchTickets, 8000);
    return () => clearInterval(interval);
  }, [installerId]);

  // Update Ticket Status
  const handleUpdateStatus = async (ticketId: string, status: Ticket['status'], notes?: string) => {
    try {
      const res = await fetch(`/api/tickets/${ticketId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status,
          resolutionNotes: notes,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(
          status === 'resolved'
            ? 'Ticket marked Resolved! Telegram update dispatched.'
            : `Ticket status updated to ${status}.`,
          'success'
        );
        fetchTickets();
        setResolutionPromptId(null);
        setResolutionNote('');
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'alert');
    }
  };

  // Delete Ticket
  const handleDeleteTicket = async (ticketId: string) => {
    if (!window.confirm('Delete this support ticket?')) return;
    try {
      const res = await fetch(`/api/tickets/${ticketId}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setTickets((prev) => prev.filter((t) => t.id !== ticketId));
        showToast('Ticket deleted.', 'info');
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'alert');
    }
  };

  // Save Auto-Ticket Settings
  const handleSaveAutoTicketConfig = async () => {
    await onUpdateSettings({
      autoTicketingEnabled: autoTicketEnabled,
      autoTicketTimeoutMinutes: timeoutMinutes,
    });
    showToast('Auto-Ticketing watchdog settings saved!', 'success');
  };

  // Test Auto-Ticketing on Inactive Link
  const handleSimulateInactiveLink = async () => {
    if (devices.length === 0) {
      showToast('Please add at least 1 device or load samples first.', 'alert');
      return;
    }
    const targetDev = devices[0];
    try {
      // Set device status to offline and trigger ticket
      const res = await fetch('/api/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          installerId,
          deviceId: targetDev.id,
          clientName: targetDev.clientName,
          clientContact: targetDev.ip,
          title: `⚡ [TEST AUTO-TICKET] Inactive Link: ${targetDev.name}`,
          description: `Watchdog Trigger: Link has been inactive for > ${timeoutMinutes} minutes without telemetry heartbeat. IP: ${targetDev.ip}, Model: ${targetDev.model}.`,
          category: 'auto_offline',
          priority: 'critical',
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Auto-Ticket #${data.ticket.ticketNumber} created & sent to Telegram!`, 'success');
        fetchTickets();
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'alert');
    }
  };

  // Filtered Tickets
  const filteredTickets = tickets.filter((t) => {
    if (filterStatus === 'open' && t.status !== 'open') return false;
    if (filterStatus === 'in_progress' && t.status !== 'in_progress') return false;
    if (filterStatus === 'resolved' && (t.status !== 'resolved' && t.status !== 'closed')) return false;
    if (filterStatus === 'auto' && !t.isAutoGenerated) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        t.ticketNumber.toLowerCase().includes(q) ||
        t.clientName.toLowerCase().includes(q) ||
        t.title.toLowerCase().includes(q) ||
        (t.deviceName && t.deviceName.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const openCount = tickets.filter((t) => t.status === 'open').length;
  const inProgressCount = tickets.filter((t) => t.status === 'in_progress').length;
  const autoCount = tickets.filter((t) => t.isAutoGenerated && t.status !== 'resolved').length;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-cyan-950/60 via-slate-900 to-indigo-950/50 border border-cyan-700/40 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="p-3 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
              <LifeBuoy className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-white tracking-wide flex items-center space-x-2">
                <span>Client Support Tickets & Inactive Link Watchdog</span>
                <span className="bg-cyan-500/20 text-cyan-300 text-[10px] px-2 py-0.5 rounded-full border border-cyan-500/40 uppercase font-mono">
                  Auto-Ticketing Active
                </span>
              </h2>
              <p className="text-xs text-gray-300">
                Manage client trouble tickets and automatically generate critical tickets when wireless links go offline or drop heartbeat.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsFilingModalOpen(true)}
            className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs px-4 py-2.5 rounded-xl transition shadow flex items-center space-x-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>File New Client Ticket</span>
          </button>
        </div>

        {/* Quick Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3">
            <div className="text-[10px] uppercase text-gray-400 font-semibold">Open Tickets</div>
            <div className="text-xl font-bold font-mono text-amber-400">{openCount}</div>
            <div className="text-[10px] text-gray-500">Requires technician action</div>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3">
            <div className="text-[10px] uppercase text-gray-400 font-semibold">In Progress</div>
            <div className="text-xl font-bold font-mono text-cyan-400">{inProgressCount}</div>
            <div className="text-[10px] text-gray-500">Being serviced</div>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3">
            <div className="text-[10px] uppercase text-gray-400 font-semibold">Auto-Generated</div>
            <div className="text-xl font-bold font-mono text-red-400">{autoCount}</div>
            <div className="text-[10px] text-gray-500">From inactive links</div>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3">
            <div className="text-[10px] uppercase text-gray-400 font-semibold">Total Handled</div>
            <div className="text-xl font-bold font-mono text-emerald-400">{tickets.length}</div>
            <div className="text-[10px] text-gray-500">All-time tickets</div>
          </div>
        </div>
      </div>

      {/* Auto-Ticketing Inactive Link Watchdog Config */}
      <div className="bg-[#0F172A] border border-amber-600/30 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <Zap className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="font-bold text-sm text-white">
                Auto-Ticket Engine for Inactive & Offline Links
              </h3>
              <p className="text-xs text-gray-400">
                Automatically opens a critical support ticket and pings your Telegram when an antenna fails to report telemetry.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleSimulateInactiveLink}
              className="bg-amber-950/80 hover:bg-amber-900 text-amber-300 border border-amber-600/60 px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center space-x-1"
              title="Test the auto-ticketing engine"
            >
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Simulate Inactive Trigger</span>
            </button>
          </div>
        </div>

        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center space-x-3">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={autoTicketEnabled}
                onChange={(e) => setAutoTicketEnabled(e.target.checked)}
                className="w-4 h-4 rounded accent-cyan-500"
              />
              <span className="font-bold text-white">Enable Auto-Ticketing for Inactive Links</span>
            </label>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-gray-400">Trigger after no heartbeat for:</span>
            <input
              type="number"
              min="1"
              max="60"
              value={timeoutMinutes}
              onChange={(e) => setTimeoutMinutes(parseInt(e.target.value) || 5)}
              className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white font-mono text-center"
            />
            <span className="text-gray-300 font-semibold">minutes</span>

            <button
              onClick={handleSaveAutoTicketConfig}
              className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold px-3 py-1 rounded transition ml-2 cursor-pointer"
            >
              Save Settings
            </button>
          </div>
        </div>
      </div>

      {/* Ticket List Section */}
      <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        {/* Filters and Search Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
          <div className="flex items-center space-x-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setFilterStatus('all')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition cursor-pointer ${
                filterStatus === 'all' ? 'bg-cyan-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              All ({tickets.length})
            </button>
            <button
              onClick={() => setFilterStatus('open')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition cursor-pointer ${
                filterStatus === 'open' ? 'bg-amber-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              Open ({openCount})
            </button>
            <button
              onClick={() => setFilterStatus('in_progress')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition cursor-pointer ${
                filterStatus === 'in_progress' ? 'bg-cyan-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              In Progress ({inProgressCount})
            </button>
            <button
              onClick={() => setFilterStatus('auto')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition cursor-pointer ${
                filterStatus === 'auto' ? 'bg-red-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              ⚡ Auto-Generated ({autoCount})
            </button>
            <button
              onClick={() => setFilterStatus('resolved')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition cursor-pointer ${
                filterStatus === 'resolved' ? 'bg-emerald-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              Resolved
            </button>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by client, ticket #, or link..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-4 py-1.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-500 w-64"
            />
          </div>
        </div>

        {/* Tickets Feed */}
        {filteredTickets.length === 0 ? (
          <div className="text-center py-12 text-gray-500 space-y-2">
            <CheckCircle2 className="w-10 h-10 text-emerald-400/60 mx-auto" />
            <p className="font-semibold text-white text-sm">No tickets found</p>
            <p className="text-xs text-gray-500">
              No tickets match your filter. Clients can file tickets, or auto-tickets will appear if an antenna disconnects.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-800/80">
            {filteredTickets.map((t) => {
              const isOpen = t.status === 'open';
              const isInProgress = t.status === 'in_progress';
              const isResolved = t.status === 'resolved' || t.status === 'closed';

              return (
                <div key={t.id} className="py-4 space-y-3">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                        <span className="font-mono font-bold text-xs bg-slate-900 px-2 py-0.5 rounded border border-slate-700 text-cyan-300">
                          {t.ticketNumber}
                        </span>

                        {t.isAutoGenerated && (
                          <span className="bg-red-950/90 text-red-300 border border-red-600/70 text-[10px] font-bold px-2 py-0.5 rounded flex items-center space-x-1 animate-pulse">
                            <Zap className="w-3 h-3 text-red-400" />
                            <span>AUTO-GENERATED</span>
                          </span>
                        )}

                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                            t.priority === 'critical'
                              ? 'bg-red-950 text-red-300 border border-red-600'
                              : t.priority === 'high'
                              ? 'bg-amber-950 text-amber-300 border border-amber-600'
                              : 'bg-slate-800 text-gray-300 border border-slate-700'
                          }`}
                        >
                          {t.priority}
                        </span>

                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                            isOpen
                              ? 'bg-amber-500 text-black'
                              : isInProgress
                              ? 'bg-cyan-500 text-black'
                              : 'bg-emerald-950 text-emerald-300 border border-emerald-600'
                          }`}
                        >
                          {t.status.replace('_', ' ')}
                        </span>

                        <span className="text-[11px] text-gray-500">
                          Filed {new Date(t.createdAt).toLocaleString()}
                        </span>
                      </div>

                      <h4 className="font-bold text-sm text-white pt-1">{t.title}</h4>

                      <div className="text-xs text-gray-300 flex items-center space-x-2 flex-wrap gap-y-1">
                        <span>Client: <b className="text-white">{t.clientName}</b></span>
                        {t.clientContact && (
                          <>
                            <span className="text-gray-600">•</span>
                            <span className="text-gray-400 font-mono flex items-center space-x-1">
                              <Phone className="w-3 h-3 text-gray-500" />
                              <span>{t.clientContact}</span>
                            </span>
                          </>
                        )}
                        {t.deviceName && (
                          <>
                            <span className="text-gray-600">•</span>
                            <span className="text-cyan-400 flex items-center space-x-1">
                              <Radio className="w-3 h-3" />
                              <span>{t.deviceName}</span>
                            </span>
                          </>
                        )}
                      </div>

                      <p className="text-xs text-gray-400 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/80 leading-relaxed">
                        {t.description}
                      </p>

                      {t.resolutionNotes && (
                        <div className="text-xs text-emerald-300 bg-emerald-950/30 p-2 rounded-lg border border-emerald-800/50">
                          <b>Resolution Note:</b> {t.resolutionNotes}
                        </div>
                      )}
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center space-x-2 shrink-0">
                      {isOpen && (
                        <button
                          onClick={() => handleUpdateStatus(t.id, 'in_progress')}
                          className="bg-cyan-600 hover:bg-cyan-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold shadow transition cursor-pointer"
                        >
                          Mark In Progress
                        </button>
                      )}

                      {!isResolved && (
                        <button
                          onClick={() => setResolutionPromptId(t.id)}
                          className="bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold shadow transition cursor-pointer flex items-center space-x-1"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Resolve</span>
                        </button>
                      )}

                      <button
                        onClick={() => handleDeleteTicket(t.id)}
                        className="text-gray-500 hover:text-red-400 p-1.5 rounded hover:bg-slate-800 transition cursor-pointer"
                        title="Delete ticket"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Inline Resolution Note Prompt */}
                  {resolutionPromptId === t.id && (
                    <div className="bg-slate-900/90 border border-emerald-500/40 p-3 rounded-xl space-y-2 animate-in fade-in text-xs">
                      <label className="block text-emerald-300 font-semibold">
                        Enter Technician Resolution Notes:
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Realigned dish, restored POE power, throughput back to 22 Mbps"
                        value={resolutionNote}
                        onChange={(e) => setResolutionNote(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                      />
                      <div className="flex items-center justify-end space-x-2">
                        <button
                          onClick={() => setResolutionPromptId(null)}
                          className="text-gray-400 hover:text-white px-3 py-1 rounded"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={() => handleUpdateStatus(t.id, 'resolved', resolutionNote)}
                          className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold px-4 py-1.5 rounded-lg shadow"
                        >
                          Confirm & Close Ticket
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Client Ticket Filing Modal */}
      <ClientTicketModal
        isOpen={isFilingModalOpen}
        onClose={() => setIsFilingModalOpen(false)}
        devices={devices}
        installerId={installerId}
        onTicketCreated={() => fetchTickets()}
        showToast={showToast}
      />
    </div>
  );
};
