import React, { useState } from 'react';
import { 
  Wifi, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Sliders, 
  Send, 
  Edit3, 
  Trash2, 
  Clock, 
  DollarSign, 
  Activity,
  Zap,
  Radio,
  Layers,
  Users
} from 'lucide-react';
import { Device } from '../types';

interface DeviceCardProps {
  device: Device;
  globalThreshold: number;
  onUpdateSpeed: (deviceId: string, throughput: number, capacity: number) => void;
  onEditDevice: (device: Device) => void;
  onDeleteDevice: (deviceId: string) => void;
  onTriggerTestAlert: (device: Device) => void;
}

export const DeviceCard: React.FC<DeviceCardProps> = ({
  device,
  globalThreshold,
  onUpdateSpeed,
  onEditDevice,
  onDeleteDevice,
  onTriggerTestAlert,
}) => {
  const [sliderSpeed, setSliderSpeed] = useState<number>(device.throughput);
  const [showSimulator, setShowSimulator] = useState<boolean>(false);

  const threshold = device.speedThreshold || globalThreshold;
  const isSpeedLow = device.throughput < threshold;
  const isOffline = device.status === 'offline';
  const utilization = Math.min(100, Math.round((device.throughput / Math.max(device.capacity, 1)) * 100));

  // Circular gauge math (radius 42, circumference ~264)
  const radius = 42;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (utilization / 100) * circumference;

  const handleApplySpeed = () => {
    onUpdateSpeed(device.id, Number(sliderSpeed), device.capacity);
  };

  const isPtMp = device.topology === 'ptmp';
  const isAp = device.deviceRole === 'ap';

  return (
    <div
      className={`relative bg-[#0F172A] border rounded-2xl p-5 shadow-xl transition-all duration-200 overflow-hidden ${
        isOffline
          ? 'border-red-600/60 shadow-red-950/20 bg-gradient-to-b from-[#251218] to-[#0F172A]'
          : isSpeedLow
          ? 'border-amber-500/60 shadow-amber-950/20 bg-gradient-to-b from-[#1E1B2E] to-[#0F172A]'
          : 'border-slate-800 hover:border-cyan-500/40 hover:shadow-cyan-950/20'
      }`}
    >
      {/* Top Banner Alert if low speed or offline */}
      {isOffline ? (
        <div className="absolute top-0 inset-x-0 bg-red-600/30 border-b border-red-500/50 px-3 py-1 flex items-center justify-between text-xs text-red-200 font-medium">
          <div className="flex items-center space-x-1.5">
            <AlertTriangle className="w-3.5 h-3.5 text-red-400 animate-bounce" />
            <span>Link Inactive / Offline (Auto-Ticket Monitored)</span>
          </div>
          <span className="font-mono bg-red-950/90 px-1.5 py-0.2 rounded border border-red-500/40 text-[11px]">
            0.00 Mbps
          </span>
        </div>
      ) : isSpeedLow ? (
        <div className="absolute top-0 inset-x-0 bg-amber-500/20 border-b border-amber-500/40 px-3 py-1 flex items-center justify-between text-xs text-amber-300 font-medium">
          <div className="flex items-center space-x-1.5">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 animate-bounce" />
            <span>Low Throughput Alert: &lt; {threshold} Mbps</span>
          </div>
          <span className="font-mono bg-amber-950/80 px-1.5 py-0.2 rounded border border-amber-500/40 text-[11px]">
            {device.throughput.toFixed(2)} Mbps
          </span>
        </div>
      ) : null}

      {/* Main Device Header */}
      <div className={`flex items-start justify-between gap-3 ${isSpeedLow || isOffline ? 'mt-6' : ''}`}>
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                isOffline
                  ? 'bg-red-500 animate-pulse'
                  : isSpeedLow
                  ? 'bg-amber-400 animate-pulse'
                  : 'bg-emerald-400'
              }`}
            />
            <h3 className="font-semibold text-base text-white tracking-wide flex items-center gap-1.5">
              <span>{device.name}</span>
            </h3>

            {/* Topology Badge (P2P vs PtMP) */}
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase font-mono ${
                isPtMp
                  ? isAp
                    ? 'bg-purple-950 text-purple-300 border border-purple-600'
                    : 'bg-indigo-950 text-indigo-300 border border-indigo-700'
                  : 'bg-blue-950 text-blue-300 border border-blue-700'
              }`}
            >
              {isPtMp ? (isAp ? 'PtMP Base AP' : 'PtMP CPE') : 'P2P Link'}
            </span>
          </div>

          <p className="text-xs text-cyan-400 font-medium flex items-center gap-1">
            <Radio className="w-3 h-3 text-cyan-400" />
            <span>{device.model}</span>
            <span className="text-gray-500">•</span>
            <span className="text-gray-300">{device.clientName}</span>

            {isPtMp && isAp && device.connectedStationsCount !== undefined && (
              <>
                <span className="text-gray-500">•</span>
                <span className="text-purple-300 flex items-center space-x-1 font-mono">
                  <Users className="w-3 h-3" />
                  <span>{device.connectedStationsCount} Stations</span>
                </span>
              </>
            )}
          </p>
        </div>

        {/* Action icons */}
        <div className="flex items-center space-x-1 text-gray-400">
          <button
            onClick={() => setShowSimulator(!showSimulator)}
            className={`p-1.5 rounded-lg border text-xs transition cursor-pointer ${
              showSimulator
                ? 'bg-cyan-900/60 border-cyan-500 text-cyan-300'
                : 'bg-slate-800/80 border-slate-700 hover:text-white'
            }`}
            title="Toggle Live Speed Simulator"
          >
            <Sliders className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onEditDevice(device)}
            className="p-1.5 rounded-lg bg-slate-800/80 border border-slate-700 hover:text-white transition cursor-pointer"
            title="Edit Client & Link Settings"
          >
            <Edit3 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onDeleteDevice(device.id)}
            className="p-1.5 rounded-lg bg-slate-800/80 border border-slate-700 hover:text-red-400 transition cursor-pointer"
            title="Delete Link"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Center Section: UISP-style Gauge & Specs */}
      <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-4 items-center bg-[#0B132B]/60 p-4 rounded-xl border border-slate-800/80">
        {/* Left: UISP Circular Gauge matching user's image */}
        <div className="flex items-center justify-center space-x-3">
          <div className="relative w-24 h-24 flex items-center justify-center shrink-0">
            <svg className="w-24 h-24 transform -rotate-90">
              <circle
                cx="48"
                cy="48"
                r={radius}
                stroke="#1E293B"
                strokeWidth="7"
                fill="transparent"
              />
              <circle
                cx="48"
                cy="48"
                r={radius}
                stroke={isOffline ? '#EF4444' : isSpeedLow ? '#F59E0B' : '#06B6D4'}
                strokeWidth="7"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
                className="transition-all duration-500 ease-out"
              />
            </svg>

            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-[10px] text-gray-400 font-mono tracking-tighter uppercase">
                {isOffline ? 'OFFLINE' : `${utilization}%`}
              </span>
              <span
                className={`text-sm font-extrabold font-mono tracking-tight ${
                  isOffline ? 'text-red-400' : isSpeedLow ? 'text-amber-400' : 'text-cyan-300'
                }`}
              >
                {device.throughput.toFixed(2)}
              </span>
              <span className="text-[9px] text-gray-400 font-semibold">Mbps</span>
            </div>
          </div>

          <div className="space-y-1">
            <div className="text-[10px] uppercase tracking-wider text-gray-400 font-bold">
              THROUGHPUT CAPACITY
            </div>
            <div className="text-xl font-black text-cyan-400 font-mono tracking-tight">
              {device.capacity.toFixed(2)} <span className="text-xs text-gray-400 font-normal">Mbps</span>
            </div>
            <div className="text-[11px] text-gray-300 flex items-center gap-1 font-mono">
              <span className="text-gray-500">TX POWER:</span>
              <span className="text-cyan-400 font-bold">{device.txPower} dBm</span>
            </div>
          </div>
        </div>

        {/* Right: Technical Link Diagnostics */}
        <div className="space-y-1.5 text-xs text-gray-300 border-t sm:border-t-0 sm:border-l border-slate-800 pt-3 sm:pt-0 sm:pl-4 font-mono">
          <div className="flex justify-between items-center">
            <span className="text-gray-500">IP ADDRESS:</span>
            <span className="text-white font-bold">{device.ip}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">MAC ADDRESS:</span>
            <span className="text-gray-400">{device.mac}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">SIGNAL / RSSI:</span>
            <span
              className={`font-bold ${
                device.signal > -65
                  ? 'text-emerald-400'
                  : device.signal > -75
                  ? 'text-amber-400'
                  : 'text-red-400'
              }`}
            >
              {device.signal} dBm
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">LATENCY:</span>
            <span className={device.latency > 15 ? 'text-amber-400' : 'text-gray-300'}>
              {device.latency} ms
            </span>
          </div>
        </div>
      </div>

      {/* Simulator Drawer */}
      {showSimulator && (
        <div className="mt-4 p-4 bg-slate-950/80 border border-slate-800 rounded-xl space-y-3 animate-in fade-in duration-150">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-gray-300 flex items-center gap-1">
              <Sliders className="w-3.5 h-3.5 text-cyan-400" />
              <span>Throughput Simulator</span>
            </span>
            <span className="font-mono text-cyan-400 font-bold">{sliderSpeed} Mbps</span>
          </div>

          <div className="flex items-center space-x-3">
            <input
              type="range"
              min="0.5"
              max={Math.max(device.capacity, 40)}
              step="0.5"
              value={sliderSpeed}
              onChange={(e) => setSliderSpeed(parseFloat(e.target.value))}
              className="w-full accent-cyan-500 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between pt-1">
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setSliderSpeed(1.26);
                  onUpdateSpeed(device.id, 1.26, device.capacity);
                }}
                className="bg-amber-950/80 hover:bg-amber-900 border border-amber-600/50 text-amber-300 text-[11px] px-2.5 py-1 rounded transition cursor-pointer"
              >
                Set 1.26M (Drop Alert)
              </button>
              <button
                type="button"
                onClick={() => {
                  setSliderSpeed(22.62);
                  onUpdateSpeed(device.id, 22.62, device.capacity);
                }}
                className="bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-600/50 text-emerald-300 text-[11px] px-2.5 py-1 rounded transition cursor-pointer"
              >
                Set 22.6M (Normal)
              </button>
            </div>

            <button
              type="button"
              onClick={handleApplySpeed}
              className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs px-3 py-1 rounded shadow transition cursor-pointer"
            >
              Apply Speed
            </button>
          </div>
        </div>
      )}

      {/* Footer Info: Plan & Billing Due */}
      <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center space-x-2 text-gray-400">
          <Clock className="w-3.5 h-3.5 text-gray-500" />
          <span>Last Seen: {new Date(device.lastSeen).toLocaleTimeString()}</span>
        </div>

        <div className="flex items-center space-x-3">
          <span className="text-gray-300">
            Due: <b>{device.billingDueDay}th</b> (${device.monthlyFee}/mo)
          </span>

          <span
            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
              device.paymentStatus === 'overdue'
                ? 'bg-red-950 text-red-300 border border-red-600'
                : device.paymentStatus === 'pending'
                ? 'bg-amber-950 text-amber-300 border border-amber-600'
                : 'bg-emerald-950 text-emerald-300 border border-emerald-600'
            }`}
          >
            {device.paymentStatus}
          </span>
        </div>
      </div>
    </div>
  );
};
