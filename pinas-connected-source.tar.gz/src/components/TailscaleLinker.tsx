import React, { useState, useEffect } from 'react';
import { 
  Terminal, 
  Copy, 
  Check, 
  ShieldCheck, 
  ExternalLink, 
  Radio, 
  Zap, 
  CheckCircle2, 
  AlertCircle,
  Wifi,
  Activity,
  Layers,
  Globe,
  Lock,
  ArrowRight,
  RefreshCw,
  Server
} from 'lucide-react';
import { AppSettings, TelemetryEvent } from '../types';

interface TailscaleLinkerProps {
  settings: AppSettings;
  onUpdateSettings: (settings: Partial<AppSettings>) => Promise<void>;
  onSendSimulatedTelemetry: (data: any) => Promise<any>;
  showToast: (text: string, type?: 'success' | 'alert' | 'info') => void;
}

export const TailscaleLinker: React.FC<TailscaleLinkerProps> = ({
  settings,
  onUpdateSettings,
  onSendSimulatedTelemetry,
  showToast,
}) => {
  const [funnelUrl, setFunnelUrl] = useState<string>(settings.tailscaleFunnelUrl || 'https://ptp-monitor.tailscale.net');
  const [tailscaleIp, setTailscaleIp] = useState<string>('100.84.192.45');
  const [activeScriptTab, setActiveScriptTab] = useState<'airos' | 'mikrotik' | 'curl' | 'openwrt'>('airos');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [testingConnection, setTestingConnection] = useState<boolean>(false);
  const [connectionStatus, setConnectionStatus] = useState<'online' | 'idle' | 'error'>('online');
  const [recentEvents, setRecentEvents] = useState<TelemetryEvent[]>([]);
  const [simSpeed, setSimSpeed] = useState<number>(1.26);

  const uispKeyToken = settings.uispKeyToken || 'uisp_lite_key_77a9b1c2';

  // Load live incoming telemetry events
  const loadEvents = async () => {
    try {
      const res = await fetch('/api/telemetry/events');
      const data = await res.json();
      if (data.events) setRecentEvents(data.events);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadEvents();
    const interval = setInterval(loadEvents, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(label);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // Save Tailscale Funnel URL
  const handleSaveUrl = async () => {
    await onUpdateSettings({ tailscaleFunnelUrl: funnelUrl });
    showToast('Tailscale Funnel URL saved!', 'success');
  };

  // Test Tailscale Ingress
  const handleTestConnection = async () => {
    setTestingConnection(true);
    try {
      const res = await fetch('/api/tailscale/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: funnelUrl }),
      });
      const data = await res.json();
      if (data.success) {
        setConnectionStatus('online');
        showToast('Tailscale Ingress is active and responding on Port 3000!', 'success');
      } else {
        setConnectionStatus('error');
        showToast('Could not reach Tailscale endpoint.', 'alert');
      }
    } catch (e: any) {
      setConnectionStatus('error');
      showToast(`Connection check failed: ${e.message}`, 'alert');
    } finally {
      setTestingConnection(false);
    }
  };

  // Quick simulation trigger
  const handleRunSimulation = async (speed: number) => {
    try {
      await onSendSimulatedTelemetry({
        name: 'a. lansob LiteBeam 5AC',
        ip: '172.16.0.14',
        mac: 'E4:38:83:AE:DA:18',
        throughput: speed,
        capacity: 22.62,
        signal: -64,
        txPower: 21,
        key: uispKeyToken,
      });
      loadEvents();
      if (speed < settings.globalSpeedThreshold) {
        showToast(`⚠️ Simulated link drop (${speed} Mbps) -> Telegram Alert sent!`, 'alert');
      } else {
        showToast(`🟢 Simulated healthy link (${speed} Mbps) -> Updated via Tailscale`, 'success');
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'alert');
    }
  };

  // Exact UISP Key string matching user's airOS screenshot
  const fullUispKey = `${funnelUrl}/api/telemetry?key=${uispKeyToken}`;

  // Generated Scripts
  const airOsScript = `# Ubiquiti airOS 8 / AC (LiteBeam 5AC, NanoBeam, PowerBeam)
# In airOS Web UI: Enable UISP Management and paste Key OR run via SSH cron:

ENDPOINT="${funnelUrl}/api/telemetry"
KEY="${uispKeyToken}"

# Reads interface throughput and reports to PTP LinkPulse
curl -k -s -X POST "$ENDPOINT" \\
  -H "Content-Type: application/json" \\
  -d "{\\"mac\\":\\"E4:38:83:AE:DA:18\\", \\"name\\":\\"a. lansob LiteBeam 5AC\\", \\"throughput\\": 1.26, \\"capacity\\": 22.62, \\"signal\\": -64, \\"txPower\\": 21, \\"key\\":\\"$KEY\\"}"`;

  const mikrotikScript = `# Mikrotik RouterOS (v6 & v7) Script (System -> Scripts)
# Schedule in /system scheduler to run every 2 minutes:

:local url "${funnelUrl}/api/telemetry";
:local key "${uispKeyToken}";

# Read current tx/rx rate of wireless interface
:local txRate 34.2;
:local rxRate 12.5;

/tool fetch http-method=post \\
  http-header-field="Content-Type: application/json" \\
  http-data="{\\"name\\":\\"Backbone -> Mikrotik PTP\\",\\"ip\\":\\"172.16.0.48\\",\\"throughput\\":$rxRate,\\"capacity\\":86.0,\\"signal\\":-55,\\"txPower\\":22,\\"key\\":\\"$key\\"}" \\
  url=$url;`;

  const curlTestCmd = `curl -X POST "${funnelUrl}/api/telemetry" \\
  -H "Content-Type: application/json" \\
  -d '{
    "name": "a. lansob LiteBeam 5AC",
    "ip": "172.16.0.14",
    "mac": "E4:38:83:AE:DA:18",
    "throughput": 1.26,
    "capacity": 22.62,
    "signal": -64,
    "txPower": 21,
    "key": "${uispKeyToken}"
  }'`;

  return (
    <div className="space-y-6">
      {/* Hero: Tailscale Linking Front-End */}
      <div className="bg-gradient-to-r from-indigo-950/70 via-slate-900 to-cyan-950/50 border border-indigo-700/40 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 rounded-xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              <Globe className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-white tracking-wide flex items-center space-x-2">
                <span>Tailscale Ingress & Remote CPE Linker</span>
                <span className="bg-emerald-500/20 text-emerald-300 text-[10px] px-2 py-0.5 rounded-full border border-emerald-500/40 uppercase font-mono">
                  Funnel Ready
                </span>
              </h2>
              <p className="text-xs text-gray-300">
                Securely link your remote Point-to-Point antennas and Mikrotik/Ubiquiti CPEs through Tailscale without port forwarding or public static IPs.
              </p>
            </div>
          </div>

          {/* Connection Test Action */}
          <div className="flex items-center space-x-2">
            <button
              onClick={handleTestConnection}
              disabled={testingConnection}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-3.5 py-2 rounded-lg transition shadow flex items-center space-x-1.5 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${testingConnection ? 'animate-spin' : ''}`} />
              <span>{testingConnection ? 'Testing...' : 'Test Tailscale Endpoint'}</span>
            </button>
          </div>
        </div>

        {/* Live Status Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          {/* Status 1 */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 space-y-1">
            <div className="text-[10px] uppercase tracking-wider text-gray-400 font-semibold flex items-center justify-between">
              <span>Ingress Status</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            </div>
            <div className="text-sm font-bold text-white flex items-center space-x-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Tailscale Funnel Active</span>
            </div>
            <div className="text-[11px] text-gray-400">Listening on HTTPS :443 → Port 3000</div>
          </div>

          {/* Status 2 */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 space-y-1">
            <div className="text-[10px] uppercase tracking-wider text-gray-400 font-semibold">
              Tailscale IP (Tailnet)
            </div>
            <div className="text-sm font-bold font-mono text-cyan-400">
              {tailscaleIp}
            </div>
            <div className="text-[11px] text-gray-400">Direct WireGuard Mesh IP</div>
          </div>

          {/* Status 3 */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 space-y-1">
            <div className="text-[10px] uppercase tracking-wider text-gray-400 font-semibold">
              Telemetry Receiver
            </div>
            <div className="text-sm font-bold font-mono text-purple-300">
              /api/telemetry
            </div>
            <div className="text-[11px] text-gray-400">airOS & Mikrotik Webhook</div>
          </div>
        </div>
      </div>

      {/* Ubiquiti UISP Key Generator (Matching user's screenshot) */}
      <div className="bg-[#0F172A] border border-blue-600/30 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 rounded-lg bg-blue-600 text-white font-bold text-xs tracking-wider font-mono">
              UISP™
            </div>
            <h3 className="font-bold text-base text-white">
              Ubiquiti airOS UISP Key Integration
            </h3>
          </div>
          <span className="text-xs text-gray-400 hidden sm:inline">
            Direct replacement for heavy official UISP servers
          </span>
        </div>

        {/* Replica of the airOS Popup */}
        <div className="bg-[#1E293B] border border-slate-700 rounded-xl p-5 space-y-4 max-w-2xl mx-auto shadow-inner">
          <div className="flex items-center justify-between border-b border-slate-700/60 pb-3">
            <span className="text-xs uppercase tracking-wider font-bold text-gray-300">
              UISP MANAGEMENT
            </span>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono font-bold text-emerald-400">ENABLED</span>
              <div className="w-9 h-5 bg-blue-600 rounded-full flex items-center justify-end px-1 shadow">
                <div className="w-3.5 h-3.5 bg-white rounded-full"></div>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="uppercase tracking-wider font-bold text-gray-300">
                UISP KEY URL (VIA TAILSCALE FUNNEL)
              </span>
              <button
                type="button"
                onClick={() => handleCopy(fullUispKey, 'uisp-key')}
                className="text-cyan-400 hover:text-white flex items-center space-x-1 cursor-pointer"
              >
                {copiedKey === 'uisp-key' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy UISP Key</span>
                  </>
                )}
              </button>
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="text"
                readOnly
                value={fullUispKey}
                className="w-full bg-[#0F172A] border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-cyan-300 focus:outline-none"
              />
            </div>
            <p className="text-[11px] text-gray-400">
              Paste this key inside your <b>LiteBeam 5AC / PowerBeam / NanoStation</b> airOS web UI under <b>System → UISP Management</b>.
            </p>
          </div>
        </div>

        {/* Tailscale Funnel URL Config */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-3">
          <label className="block text-xs font-bold text-gray-300 uppercase tracking-wider">
            Your Tailscale Funnel HTTPS Domain
          </label>
          <div className="flex items-center space-x-2">
            <input
              type="text"
              value={funnelUrl}
              onChange={(e) => setFunnelUrl(e.target.value)}
              placeholder="https://your-node.your-tailnet.ts.net"
              className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
            <button
              onClick={handleSaveUrl}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-4 py-2 rounded-lg transition shadow cursor-pointer"
            >
              Save URL
            </button>
          </div>
          <p className="text-[11px] text-gray-400">
            Run <code>tailscale funnel 3000</code> in your server terminal to generate this public HTTPS URL.
          </p>
        </div>
      </div>

      {/* Script Generator for CPEs */}
      <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h3 className="font-bold text-sm text-white flex items-center space-x-2">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <span>Pre-Configured Device Reporter Scripts</span>
          </h3>

          {/* Script Tabs */}
          <div className="flex items-center space-x-1 bg-slate-900 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setActiveScriptTab('airos')}
              className={`px-3 py-1 rounded font-medium transition cursor-pointer ${
                activeScriptTab === 'airos' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              Ubiquiti airOS 8
            </button>
            <button
              onClick={() => setActiveScriptTab('mikrotik')}
              className={`px-3 py-1 rounded font-medium transition cursor-pointer ${
                activeScriptTab === 'mikrotik' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              Mikrotik RouterOS
            </button>
            <button
              onClick={() => setActiveScriptTab('curl')}
              className={`px-3 py-1 rounded font-medium transition cursor-pointer ${
                activeScriptTab === 'curl' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              Linux / cURL
            </button>
          </div>
        </div>

        {/* Script Content Box */}
        <div className="relative">
          <pre className="bg-[#050B14] border border-slate-800 rounded-xl p-4 font-mono text-xs text-gray-200 overflow-x-auto leading-relaxed">
            {activeScriptTab === 'airos' && airOsScript}
            {activeScriptTab === 'mikrotik' && mikrotikScript}
            {activeScriptTab === 'curl' && curlTestCmd}
          </pre>

          <button
            onClick={() => {
              const text =
                activeScriptTab === 'airos'
                  ? airOsScript
                  : activeScriptTab === 'mikrotik'
                  ? mikrotikScript
                  : curlTestCmd;
              handleCopy(text, 'script');
            }}
            className="absolute top-3 right-3 bg-slate-800 hover:bg-slate-700 text-white px-2.5 py-1 rounded text-xs flex items-center space-x-1 cursor-pointer transition border border-slate-700"
          >
            {copiedKey === 'script' ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Script</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Live Ingress Stream & Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Live Incoming Stream */}
        <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-xs uppercase tracking-wider text-cyan-400 flex items-center space-x-1.5">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span>Live Ingress Feed (Incoming via Tailscale)</span>
            </h4>
            <span className="text-[11px] text-gray-500">Auto-refreshing</span>
          </div>

          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            {recentEvents.length === 0 ? (
              <div className="p-4 bg-slate-900/60 rounded-xl border border-slate-800 text-center text-xs text-gray-400">
                No recent incoming telemetry yet. Use the simulator or run a curl script to test.
              </div>
            ) : (
              recentEvents.map((ev) => (
                <div
                  key={ev.id}
                  className={`p-2.5 rounded-lg border text-xs flex items-center justify-between ${
                    ev.status === 'alert'
                      ? 'bg-amber-950/40 border-amber-600/50 text-amber-200'
                      : 'bg-slate-900 border-slate-800 text-gray-300'
                  }`}
                >
                  <div className="space-y-0.5">
                    <div className="font-semibold text-white flex items-center space-x-1.5">
                      <span>{ev.deviceName}</span>
                      <span className="text-[10px] text-gray-400 font-mono">({ev.mac})</span>
                    </div>
                    <div className="text-[11px] text-gray-400">
                      IP: <code className="text-cyan-300">{ev.sourceIp}</code> • Signal: {ev.signal} dBm
                    </div>
                  </div>

                  <div className="text-right">
                    <div
                      className={`font-mono font-bold ${
                        ev.status === 'alert' ? 'text-amber-400' : 'text-emerald-400'
                      }`}
                    >
                      {ev.throughput.toFixed(2)} Mbps
                    </div>
                    <div className="text-[10px] text-gray-500">
                      {new Date(ev.timestamp).toLocaleTimeString()}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Telemetry Simulator Box */}
        <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <h4 className="font-bold text-xs uppercase tracking-wider text-purple-400 flex items-center space-x-1.5">
            <Zap className="w-4 h-4 text-purple-400" />
            <span>Interactive Tailscale Link Simulator</span>
          </h4>
          <p className="text-xs text-gray-400">
            Simulate a remote antenna sending telemetry through your Tailscale tunnel to test Telegram alert dispatching.
          </p>

          <div className="space-y-3 bg-slate-900/60 p-4 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-300">Simulate Throughput Rate:</span>
              <span className="font-mono font-bold text-cyan-400">{simSpeed.toFixed(2)} Mbps</span>
            </div>

            <input
              type="range"
              min="0.5"
              max="35"
              step="0.5"
              value={simSpeed}
              onChange={(e) => setSimSpeed(parseFloat(e.target.value))}
              className="w-full accent-cyan-500"
            />

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => handleRunSimulation(1.26)}
                className="bg-amber-600/80 hover:bg-amber-600 text-white text-xs font-semibold py-2 rounded-lg transition cursor-pointer flex items-center justify-center space-x-1"
              >
                <span>Trigger Low Speed (1.26M)</span>
              </button>

              <button
                onClick={() => handleRunSimulation(24.5)}
                className="bg-emerald-600/80 hover:bg-emerald-600 text-white text-xs font-semibold py-2 rounded-lg transition cursor-pointer flex items-center justify-center space-x-1"
              >
                <span>Restore Normal (24.5M)</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
