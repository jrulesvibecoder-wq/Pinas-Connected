import React, { useState, useEffect } from 'react';
import { X, Plus, Save, Radio, Shield, DollarSign, Calendar, Layers, Wifi } from 'lucide-react';
import { Device, TopologyType, DeviceRole } from '../types';

interface DeviceModalProps {
  isOpen: boolean;
  onClose: () => void;
  deviceToEdit: Device | null;
  globalThreshold: number;
  existingDevices?: Device[];
  onSave: (deviceData: any) => void;
}

export const DeviceModal: React.FC<DeviceModalProps> = ({
  isOpen,
  onClose,
  deviceToEdit,
  globalThreshold,
  existingDevices = [],
  onSave,
}) => {
  if (!isOpen) return null;

  const [topology, setTopology] = useState<TopologyType>(deviceToEdit?.topology || 'p2p');
  const [deviceRole, setDeviceRole] = useState<DeviceRole>(deviceToEdit?.deviceRole || 'station');
  const [sectorApId, setSectorApId] = useState<string>(deviceToEdit?.sectorApId || '');
  const [connectedStationsCount, setConnectedStationsCount] = useState<number>(deviceToEdit?.connectedStationsCount || 4);
  const [channelWidth, setChannelWidth] = useState<number>(deviceToEdit?.channelWidth || 40);
  const [frequency, setFrequency] = useState<number>(deviceToEdit?.frequency || 5745);

  const [name, setName] = useState(deviceToEdit?.name || '');
  const [clientName, setClientName] = useState(deviceToEdit?.clientName || '');
  const [model, setModel] = useState(deviceToEdit?.model || 'LiteBeam 5AC');
  const [ip, setIp] = useState(deviceToEdit?.ip || '172.16.0.');
  const [mac, setMac] = useState(deviceToEdit?.mac || 'E4:38:83:');
  const [txPower, setTxPower] = useState(deviceToEdit?.txPower || 21);
  const [speedThreshold, setSpeedThreshold] = useState(
    deviceToEdit?.speedThreshold || globalThreshold || 5.0
  );
  const [planName, setPlanName] = useState(deviceToEdit?.planName || '15 Mbps Standard');
  const [billingDueDay, setBillingDueDay] = useState(deviceToEdit?.billingDueDay || 5);
  const [monthlyFee, setMonthlyFee] = useState(deviceToEdit?.monthlyFee || 25.0);

  useEffect(() => {
    if (deviceToEdit) {
      setTopology(deviceToEdit.topology || 'p2p');
      setDeviceRole(deviceToEdit.deviceRole || 'station');
      setSectorApId(deviceToEdit.sectorApId || '');
      setConnectedStationsCount(deviceToEdit.connectedStationsCount || 4);
      setChannelWidth(deviceToEdit.channelWidth || 40);
      setFrequency(deviceToEdit.frequency || 5745);
      setName(deviceToEdit.name);
      setClientName(deviceToEdit.clientName);
      setModel(deviceToEdit.model);
      setIp(deviceToEdit.ip);
      setMac(deviceToEdit.mac);
      setTxPower(deviceToEdit.txPower);
      setSpeedThreshold(deviceToEdit.speedThreshold);
      setPlanName(deviceToEdit.planName);
      setBillingDueDay(deviceToEdit.billingDueDay);
      setMonthlyFee(deviceToEdit.monthlyFee);
    } else {
      setTopology('p2p');
      setDeviceRole('station');
      setName('a. lansob LiteBeam 5AC');
      setClientName('Alejandro Lansob');
      setModel('LiteBeam 5AC');
      setIp('172.16.0.14');
      setMac('E4:38:83:AE:DA:18');
      setTxPower(21);
      setSpeedThreshold(globalThreshold || 5.0);
      setPlanName('15 Mbps Standard');
      setBillingDueDay(5);
      setMonthlyFee(25.0);
    }
  }, [deviceToEdit, globalThreshold]);

  // Handle topology toggle
  const handleTopologyChange = (top: TopologyType) => {
    setTopology(top);
    if (top === 'ptmp') {
      if (deviceRole === 'standalone') setDeviceRole('station');
      if (deviceRole === 'ap') setModel('Rocket 5AC Prism Gen2');
      else setModel('LiteBeam 5AC');
    } else {
      setDeviceRole('standalone');
      setModel('PowerBeam 5AC Gen2');
    }
  };

  const handleRoleChange = (role: DeviceRole) => {
    setDeviceRole(role);
    if (role === 'ap') {
      setModel('Rocket 5AC Prism Gen2');
      if (!name || name.includes('LiteBeam')) setName('Tower Sector 90° AP');
      if (!clientName) setClientName('Tower Base Station');
    } else {
      setModel('LiteBeam 5AC');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name,
      clientName,
      model,
      topology,
      deviceRole,
      sectorApId: topology === 'ptmp' && deviceRole === 'station' ? sectorApId : undefined,
      connectedStationsCount: topology === 'ptmp' && deviceRole === 'ap' ? Number(connectedStationsCount) : undefined,
      channelWidth: Number(channelWidth),
      frequency: Number(frequency),
      ip,
      mac,
      txPower: Number(txPower),
      speedThreshold: Number(speedThreshold),
      planName,
      billingDueDay: Number(billingDueDay),
      monthlyFee: Number(monthlyFee),
    });
    onClose();
  };

  // Find existing AP sectors
  const sectorAps = existingDevices.filter((d) => d.topology === 'ptmp' && d.deviceRole === 'ap');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-[#111827] border border-cyan-500/40 rounded-2xl shadow-2xl w-full max-w-lg text-gray-100 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-150">
        <div className="bg-[#0066CC] px-6 py-4 flex items-center justify-between text-white">
          <div className="flex items-center space-x-2">
            <Radio className="w-5 h-5 text-cyan-200" />
            <h2 className="font-bold text-base tracking-wide">
              {deviceToEdit ? 'Edit Wireless Link' : 'Add Wireless Link'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-blue-200 hover:text-white p-1 rounded-md transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
          {/* Topology Selection (P2P vs PtMP) */}
          <div className="space-y-1.5 bg-slate-900/80 p-3 rounded-xl border border-slate-800">
            <label className="font-bold text-gray-300 uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>Network Topology</span>
            </label>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => handleTopologyChange('p2p')}
                className={`py-2 px-3 rounded-lg font-bold text-xs border transition cursor-pointer flex items-center justify-center space-x-1.5 ${
                  topology === 'p2p'
                    ? 'bg-blue-600 border-blue-400 text-white shadow'
                    : 'bg-slate-950 border-slate-800 text-gray-400 hover:text-white'
                }`}
              >
                <Radio className="w-3.5 h-3.5" />
                <span>P2P (Point-to-Point)</span>
              </button>

              <button
                type="button"
                onClick={() => handleTopologyChange('ptmp')}
                className={`py-2 px-3 rounded-lg font-bold text-xs border transition cursor-pointer flex items-center justify-center space-x-1.5 ${
                  topology === 'ptmp'
                    ? 'bg-purple-600 border-purple-400 text-white shadow'
                    : 'bg-slate-950 border-slate-800 text-gray-400 hover:text-white'
                }`}
              >
                <Wifi className="w-3.5 h-3.5" />
                <span>PtMP (Point-to-Multipoint)</span>
              </button>
            </div>

            {/* If PtMP: Select Role (Base Station AP vs Client Station) */}
            {topology === 'ptmp' && (
              <div className="pt-2 border-t border-slate-800/80 mt-2 space-y-2">
                <div className="flex items-center space-x-2">
                  <span className="text-gray-400 font-semibold">PtMP Role:</span>
                  <label className="flex items-center space-x-1 cursor-pointer">
                    <input
                      type="radio"
                      name="deviceRole"
                      checked={deviceRole === 'station'}
                      onChange={() => handleRoleChange('station')}
                      className="accent-purple-500"
                    />
                    <span className="text-white">Client CPE (Station)</span>
                  </label>
                  <label className="flex items-center space-x-1 cursor-pointer ml-3">
                    <input
                      type="radio"
                      name="deviceRole"
                      checked={deviceRole === 'ap'}
                      onChange={() => handleRoleChange('ap')}
                      className="accent-purple-500"
                    />
                    <span className="text-purple-300 font-bold">Base Station (Sector AP)</span>
                  </label>
                </div>

                {deviceRole === 'station' && sectorAps.length > 0 && (
                  <div>
                    <label className="block text-gray-400 mb-1">Attached Sector AP</label>
                    <select
                      value={sectorApId}
                      onChange={(e) => setSectorApId(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-white"
                    >
                      <option value="">-- Standalone PtMP Station --</option>
                      {sectorAps.map((ap) => (
                        <option key={ap.id} value={ap.id}>
                          {ap.name} ({ap.ip})
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {deviceRole === 'ap' && (
                  <div>
                    <label className="block text-gray-400 mb-1">Connected CPE Stations Capacity</label>
                    <input
                      type="number"
                      value={connectedStationsCount}
                      onChange={(e) => setConnectedStationsCount(parseInt(e.target.value) || 0)}
                      className="w-24 bg-slate-950 border border-slate-700 rounded p-1 text-white text-center font-mono"
                    />
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Link Title & Client Name */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-gray-300">LINK / AP NAME</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. a. lansob LiteBeam 5AC"
                className="w-full bg-[#1F2937] border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-cyan-500 font-medium"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-gray-300">CLIENT / SITE OWNER</label>
              <input
                type="text"
                required
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder="e.g. Alejandro Lansob"
                className="w-full bg-[#1F2937] border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-cyan-500 font-medium"
              />
            </div>
          </div>

          {/* Hardware Model & IP Address */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-gray-300">HARDWARE MODEL</label>
              <select
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="w-full bg-[#1F2937] border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-cyan-500 font-medium"
              >
                <optgroup label="Ubiquiti airMAX AC">
                  <option value="LiteBeam 5AC">LiteBeam 5AC (Client Station)</option>
                  <option value="PowerBeam 5AC Gen2">PowerBeam 5AC Gen2 (P2P / Long Range)</option>
                  <option value="NanoBeam 5AC">NanoBeam 5AC</option>
                  <option value="NanoStation 5AC">NanoStation 5AC / Loco</option>
                  <option value="Rocket 5AC Prism Gen2">Rocket 5AC Prism (PtMP Base Station)</option>
                  <option value="LiteAP AC">LiteAP AC (PtMP Sector 120°)</option>
                  <option value="airFiber 5XHD">airFiber 5XHD (Gigabit Backhaul)</option>
                </optgroup>
                <optgroup label="Mikrotik RouterOS Wireless">
                  <option value="Mikrotik LHG 5 ac">Mikrotik LHG 5 ac</option>
                  <option value="Mikrotik SXTsq 5 ac">Mikrotik SXTsq 5 ac</option>
                  <option value="Mikrotik NetMetal ac2">Mikrotik NetMetal ac2 (PtMP AP)</option>
                </optgroup>
                <optgroup label="Mimosa / Cambium">
                  <option value="Mimosa C5c">Mimosa C5c</option>
                  <option value="Cambium ePMP 3000">Cambium ePMP 3000</option>
                </optgroup>
              </select>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-gray-300">MANAGEMENT IP (CPE/AP)</label>
              <input
                type="text"
                required
                value={ip}
                onChange={(e) => setIp(e.target.value)}
                placeholder="172.16.0.14"
                className="w-full bg-[#1F2937] border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-cyan-500 font-mono"
              />
            </div>
          </div>

          {/* MAC Address & TX Power */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-gray-300">MAC ADDRESS</label>
              <input
                type="text"
                required
                value={mac}
                onChange={(e) => setMac(e.target.value)}
                placeholder="E4:38:83:AE:DA:18"
                className="w-full bg-[#1F2937] border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-cyan-500 font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-gray-300">TX OUTPUT POWER (dBm)</label>
              <input
                type="number"
                min="0"
                max="30"
                value={txPower}
                onChange={(e) => setTxPower(parseInt(e.target.value) || 20)}
                className="w-full bg-[#1F2937] border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-cyan-500 font-mono"
              />
            </div>
          </div>

          {/* Telegram Alert Threshold */}
          <div className="bg-amber-950/30 border border-amber-500/30 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center space-x-2 text-amber-400 font-bold text-xs">
              <Shield className="w-4 h-4" />
              <span>TELEGRAM SPEED DROP TRIGGER</span>
            </div>
            <div className="flex items-center space-x-3">
              <input
                type="number"
                min="0.5"
                max="200"
                step="0.5"
                value={speedThreshold}
                onChange={(e) => setSpeedThreshold(parseFloat(e.target.value) || 5.0)}
                className="w-28 bg-[#111827] border border-amber-500/50 rounded-lg px-3 py-1.5 text-white font-mono font-bold text-center"
              />
              <span className="text-gray-300 text-xs">
                Alert me via Telegram if throughput falls below this speed.
              </span>
            </div>
          </div>

          {/* Billing & Subscription */}
          <div className="space-y-3 pt-2 border-t border-gray-800">
            <div className="font-bold text-gray-300 flex items-center space-x-1.5">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span>CLIENT BILLING & MONTHLY DUE DATE</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="text-gray-400">SERVICE PLAN</label>
                <input
                  type="text"
                  value={planName}
                  onChange={(e) => setPlanName(e.target.value)}
                  placeholder="15 Mbps Standard"
                  className="w-full bg-[#1F2937] border border-gray-700 rounded-lg px-2.5 py-1.5 text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-gray-400">DUE DAY OF MONTH</label>
                <input
                  type="number"
                  min="1"
                  max="31"
                  value={billingDueDay}
                  onChange={(e) => setBillingDueDay(parseInt(e.target.value) || 1)}
                  className="w-full bg-[#1F2937] border border-gray-700 rounded-lg px-2.5 py-1.5 text-white font-mono text-center"
                />
              </div>

              <div className="space-y-1">
                <label className="text-gray-400">MONTHLY FEE ($)</label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={monthlyFee}
                  onChange={(e) => setMonthlyFee(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#1F2937] border border-gray-700 rounded-lg px-2.5 py-1.5 text-white font-mono text-center"
                />
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-gray-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-gray-300 hover:text-white hover:bg-gray-800 transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold px-5 py-2 rounded-lg shadow-lg transition cursor-pointer flex items-center space-x-1.5"
            >
              <Save className="w-4 h-4" />
              <span>{deviceToEdit ? 'Save Changes' : 'Add Link to Monitor'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
