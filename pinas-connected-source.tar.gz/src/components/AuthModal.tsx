import React, { useState } from 'react';
import { 
  X, 
  UserPlus, 
  LogIn, 
  Sparkles, 
  Building, 
  Mail, 
  Lock, 
  Phone, 
  CheckCircle2, 
  Users,
  ShieldCheck
} from 'lucide-react';
import { User } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  availableUsers: any[];
  currentUser: User;
  onSelectUser: (user: User) => void;
  onUserRegistered: (newUser: User) => void;
  showToast: (text: string, type?: 'success' | 'alert' | 'info') => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  availableUsers,
  currentUser,
  onSelectUser,
  onUserRegistered,
  showToast,
}) => {
  const [authMode, setAuthMode] = useState<'register' | 'switch'>('register');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [phone, setPhone] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) {
      showToast('Name and Email are required', 'alert');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim(),
          companyName: companyName.trim() || `${name}'s Wireless Network`,
          phone: phone.trim(),
        }),
      });

      const data = await res.json();
      if (data.success && data.user) {
        showToast('🎉 Account created with 30-Day Free Trial!', 'success');
        onUserRegistered(data.user);
        onClose();
      } else {
        showToast(`Registration failed: ${data.error}`, 'alert');
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'alert');
    } finally {
      setSubmitting(false);
    }
  };

  const handleQuickLogin = async (userEmail: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: userEmail }),
      });
      const data = await res.json();
      if (data.success && data.user) {
        onSelectUser(data.user);
        showToast(`Switched account to ${data.user.name}`, 'info');
        onClose();
      }
    } catch (e: any) {
      showToast(`Login error: ${e.message}`, 'alert');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#0F172A] border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-[#1E293B] px-6 py-4 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <UserPlus className="w-5 h-5 text-cyan-400" />
            <h3 className="text-sm font-extrabold text-white tracking-wide">
              {authMode === 'register' ? 'New Installer Registration' : 'Switch Account / Log In'}
            </h3>
          </div>

          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-slate-700 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free 30-Day Trial Offer Banner */}
        <div className="bg-gradient-to-r from-blue-900/60 to-purple-900/60 p-4 border-b border-blue-800/40 text-xs text-blue-200 flex items-start space-x-2.5">
          <Sparkles className="w-5 h-5 text-amber-300 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-white">First 30 Days Free Trial!</span>
            <p className="text-[11px] text-gray-300 mt-0.5">
              Full monitoring for all your PTP links, Telegram alerts for bandwidth drops, and Tailscale Funnel. No credit card required upfront.
            </p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-800 text-xs">
          <button
            onClick={() => setAuthMode('register')}
            className={`flex-1 py-2.5 font-semibold text-center transition cursor-pointer ${
              authMode === 'register'
                ? 'text-cyan-400 border-b-2 border-cyan-400 bg-slate-900/40'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Create Installer Account
          </button>
          <button
            onClick={() => setAuthMode('switch')}
            className={`flex-1 py-2.5 font-semibold text-center transition cursor-pointer ${
              authMode === 'switch'
                ? 'text-cyan-400 border-b-2 border-cyan-400 bg-slate-900/40'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Switch / Demo Accounts
          </button>
        </div>

        {/* Body */}
        <div className="p-6">
          {authMode === 'register' ? (
            <form onSubmit={handleRegister} className="space-y-4 text-xs">
              <div>
                <label className="block text-gray-300 font-semibold mb-1">Your Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Juan Installer"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  placeholder="juan@wisp.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-1">Company / WISP Network Name</label>
                <input
                  type="text"
                  placeholder="e.g. SkyLink Wireless Solutions"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-semibold mb-1">Phone / Telegram Handle (Optional)</label>
                <input
                  type="text"
                  placeholder="+63 917 123 4567 or @juan_ptp"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold py-2.5 rounded-lg shadow-lg transition cursor-pointer mt-2"
              >
                {submitting ? 'Creating Account...' : 'Sign Up (Start 30-Day Free Trial)'}
              </button>
            </form>
          ) : (
            <div className="space-y-3">
              <p className="text-xs text-gray-400">
                Switch between registered installer accounts or Master Admin for demo & testing:
              </p>

              <div className="space-y-2 max-h-64 overflow-y-auto">
                {availableUsers.map((u) => {
                  const isCurrent = currentUser?.id === u.id;
                  return (
                    <div
                      key={u.id}
                      onClick={() => handleQuickLogin(u.email)}
                      className={`p-3 rounded-xl border text-xs flex items-center justify-between cursor-pointer transition ${
                        isCurrent
                          ? 'bg-cyan-950/40 border-cyan-500 text-cyan-200'
                          : 'bg-slate-900/60 border-slate-800 text-gray-300 hover:bg-slate-800'
                      }`}
                    >
                      <div>
                        <div className="font-semibold text-white flex items-center space-x-1.5">
                          <span>{u.name}</span>
                          {u.role === 'admin' ? (
                            <span className="bg-purple-950 text-purple-300 text-[10px] px-1.5 py-0.2 rounded border border-purple-700">
                              Admin
                            </span>
                          ) : (
                            <span className="bg-blue-950 text-blue-300 text-[10px] px-1.5 py-0.2 rounded border border-blue-700">
                              Installer
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-gray-400 font-mono">{u.email}</div>
                      </div>

                      {isCurrent ? (
                        <span className="text-[11px] font-bold text-cyan-400 flex items-center space-x-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Active</span>
                        </span>
                      ) : (
                        <button
                          type="button"
                          className="text-xs bg-slate-800 hover:bg-slate-700 text-gray-200 px-2.5 py-1 rounded border border-slate-700"
                        >
                          Select
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
