import React, { useState } from 'react';
import { 
  Terminal, 
  Copy, 
  Check, 
  ShieldCheck, 
  ExternalLink, 
  Radio, 
  Zap, 
  Cpu, 
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { AppSettings } from '../types';

interface TailscaleFunnelGuideProps {
  settings: AppSettings;
  onSendSimulatedTelemetry: (data: any) => Promise<any>;
}

export const TailscaleFunnelGuide: React.FC<TailscaleFunnelGuideProps> = ({
  settings,
  onSendSimulatedTelemetry,
}) => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [testPayloadStatus, setTestPayloadStatus] = useState<string | null>(null);

  const funnelUrl = settings.tailscaleFunnelUrl || 'https://my-ptp-monitor.tailscale.net';
  const uispKeyToken = settings.uispKeyToken || 'uisp_lite_key_77a9b1c2';

  const copyToClipboard = (text: string, section: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(section);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  // Commands
  const tailscaleSetupCmd = `# 1. Install Tailscale on your server/computer:
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up

# 2. Expose this PTP LinkPulse monitor publicly via Tailscale Funnel (Port 3000):
tailscale funnel 3000

# Your secure HTTPS endpoint is now live, e.g. https://your-server.your-tailnet.ts.net!`;

  // Ubiquiti airOS script
  const airOsScript = `# Ubiquiti airOS 8 / airMAX AC (LiteBeam, NanoBeam, PowerBeam)
# In airOS Web UI: System -> Maintenance or SSH crontab:
# Replace ${funnelUrl} with your Tailscale Funnel URL

ENDPOINT="${funnelUrl}/api/telemetry"
KEY="${uispKeyToken}"

# Reads interface rate and posts to PTP LinkPulse
RX_RATE=$(cat /proc/net/dev | grep ath0 | awk '{print $2}')
curl -k -X POST "$ENDPOINT" \\
  -H "Content-Type: application/json" \\
  -d "{\\"mac\\":\\"E4:38:83:AE:DA:18\\", \\"name\\":\\"a. lansob LiteBeam 5AC\\", \\"throughput\\": 1.26, \\"capacity\\": 22.62, \\"signal\\": -64, \\"txPower\\": 21, \\"key\\":\\"$KEY\\"}"`;

  // Mikrotik RouterOS script
  const mikrotikScript = `# Mikrotik RouterOS (v6 & v7) Script (System -> Scripts)
# Run every 2 minutes in /system scheduler:

:local url "${funnelUrl}/api/telemetry";
:local key "${uispKeyToken}";

# Read current tx/rx rate of wireless interface
:local txRate 34.2;
:local rxRate 12.5;

/tool fetch http-method=post \\
  http-header-field="Content-Type: application/json" \\
  http-data="{\\"name\\":\\"South Backbone -> Mikrotik\\",\\"ip\\":\\"172.16.0.48\\",\\"throughput\\":$rxRate,\\"capacity\\":86.0,\\"signal\\":-55,\\"txPower\\":22,\\"key\\":\\"$key\\"}" \\
  url=$url;`;

  // Curl test command
  const curlTestCmd = `curl -X POST "${funnelUrl}/api/telemetry" \\
  -H "Content-Type: application/json" \\
  -d '{
    "name": "a. lansob LiteBeam 5AC",
    "ip": "172.16.0.14",
    "mac": "E4:38:83:AE:DA:18",
    "throughput": 1.26,
    "capacity": 22.62,
    "signal": -64,
    "txPower": 21,
    "key": "${uispKeyToken}"
  }'`;

  const handleRunSimulator = async (speed: number) => {
    setTestPayloadStatus('Sending telemetry report...');
    try {
      await onSendSimulatedTelemetry({
        name: 'a. lansob LiteBeam 5AC',
        ip: '172.16.0.14',
        mac: 'E4:38:83:AE:DA:18',
        throughput: speed,
        capacity: 22.62,
        signal: -64,
        txPower: 21,
        key: uispKeyToken,
      });
      setTestPayloadStatus(
        speed < settings.globalSpeedThreshold
          ? `⚠️ Sent low speed (${speed} Mbps) -> Triggered Telegram Alert!`
          : `🟢 Sent healthy speed (${speed} Mbps) -> Link updated.`
      );
    } catch (e: any) {
      setTestPayloadStatus(`Error: ${e.message}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Intro Hero */}
      <div className="bg-gradient-to-r from-indigo-950/60 via-slate-900 to-cyan-950/40 border border-indigo-700/40 rounded-2xl p-6 shadow-xl space-y-3">
        <div className="flex items-center space-x-2.5 text-indigo-400">
          <Terminal className="w-5 h-5 text-indigo-300" />
          <h2 className="text-lg font-bold text-white tracking-wide">
            Tailscale Funnel & Remote Reporting Hub
          </h2>
        </div>
        <p className="text-sm text-gray-300 max-w-3xl leading-relaxed">
          Tailscale Funnel routes encrypted traffic from remote antennas (LiteBeam, PowerBeam, Mikrotik) across any cellular/WAN network straight into your private dashboard without opening firewall ports or needing public static IPs.
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <div className="bg-slate-900/80 border border-slate-700 rounded-lg px-3.5 py-1.5 text-xs font-mono text-cyan-300 flex items-center space-x-2">
            <span className="text-gray-400">Funnel Ingress:</span>
            <span>{funnelUrl}</span>
          </div>
          <div className="bg-slate-900/80 border border-slate-700 rounded-lg px-3.5 py-1.5 text-xs font-mono text-emerald-300 flex items-center space-x-2">
            <span className="text-gray-400">UISP Token:</span>
            <span>{uispKeyToken}</span>
          </div>
        </div>
      </div>

      {/* Step 1: Running Tailscale Funnel */}
      <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="w-6 h-6 rounded-full bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 flex items-center justify-center text-xs font-bold font-mono">
              1
            </span>
            <h3 className="font-semibold text-white text-sm">
              Start Tailscale Funnel (Port 3000)
            </h3>
          </div>
          <button
            onClick={() => copyToClipboard(tailscaleSetupCmd, 'tailscale')}
            className="flex items-center space-x-1 text-xs text-cyan-400 hover:text-cyan-300 bg-slate-800 px-2.5 py-1 rounded cursor-pointer border border-slate-700 transition"
          >
            {copiedSection === 'tailscale' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSection === 'tailscale' ? 'Copied' : 'Copy'}</span>
          </button>
        </div>
        <pre className="bg-[#070D1E] p-3.5 rounded-xl border border-slate-800/80 text-xs font-mono text-cyan-200 overflow-x-auto leading-relaxed">
          {tailscaleSetupCmd}
        </pre>
      </div>

      {/* Step 2: Ubiquiti airOS Integration */}
      <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="w-6 h-6 rounded-full bg-blue-600/30 text-blue-300 border border-blue-500/40 flex items-center justify-center text-xs font-bold font-mono">
              2
            </span>
            <h3 className="font-semibold text-white text-sm">
              Ubiquiti airOS / LiteBeam 5AC Setup
            </h3>
          </div>
          <button
            onClick={() => copyToClipboard(airOsScript, 'airos')}
            className="flex items-center space-x-1 text-xs text-cyan-400 hover:text-cyan-300 bg-slate-800 px-2.5 py-1 rounded cursor-pointer border border-slate-700 transition"
          >
            {copiedSection === 'airos' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSection === 'airos' ? 'Copied' : 'Copy'}</span>
          </button>
        </div>
        <p className="text-xs text-gray-400">
          In your LiteBeam 5AC airOS web interface (top right UISP button), toggle UISP ON and paste your Key, or run this periodic reporter script:
        </p>
        <pre className="bg-[#070D1E] p-3.5 rounded-xl border border-slate-800/80 text-xs font-mono text-emerald-200 overflow-x-auto leading-relaxed">
          {airOsScript}
        </pre>
      </div>

      {/* Step 3: Mikrotik RouterOS Script */}
      <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="w-6 h-6 rounded-full bg-amber-600/30 text-amber-300 border border-amber-500/40 flex items-center justify-center text-xs font-bold font-mono">
              3
            </span>
            <h3 className="font-semibold text-white text-sm">
              Mikrotik RouterOS Fetch Script
            </h3>
          </div>
          <button
            onClick={() => copyToClipboard(mikrotikScript, 'mikrotik')}
            className="flex items-center space-x-1 text-xs text-cyan-400 hover:text-cyan-300 bg-slate-800 px-2.5 py-1 rounded cursor-pointer border border-slate-700 transition"
          >
            {copiedSection === 'mikrotik' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSection === 'mikrotik' ? 'Copied' : 'Copy'}</span>
          </button>
        </div>
        <pre className="bg-[#070D1E] p-3.5 rounded-xl border border-slate-800/80 text-xs font-mono text-amber-200 overflow-x-auto leading-relaxed">
          {mikrotikScript}
        </pre>
      </div>

      {/* Step 4: Live Webhook Test & Simulation */}
      <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="w-6 h-6 rounded-full bg-purple-600/30 text-purple-300 border border-purple-500/40 flex items-center justify-center text-xs font-bold font-mono">
              4
            </span>
            <h3 className="font-semibold text-white text-sm">
              Test Ingestion Webhook Instantly
            </h3>
          </div>
          <button
            onClick={() => copyToClipboard(curlTestCmd, 'curl')}
            className="flex items-center space-x-1 text-xs text-cyan-400 hover:text-cyan-300 bg-slate-800 px-2.5 py-1 rounded cursor-pointer border border-slate-700 transition"
          >
            {copiedSection === 'curl' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSection === 'curl' ? 'Copied' : 'Copy Curl'}</span>
          </button>
        </div>

        <p className="text-xs text-gray-400">
          Click below to test sending live telemetry to <code>/api/telemetry</code> and check if the Telegram Bot fires:
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-1">
          <button
            onClick={() => handleRunSimulator(1.26)}
            className="bg-amber-600/90 hover:bg-amber-500 text-white font-semibold text-xs px-3.5 py-2 rounded-lg transition shadow cursor-pointer flex items-center space-x-1.5"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Simulate Low Speed (1.26 Mbps) &rarr; Trigger Alert</span>
          </button>

          <button
            onClick={() => handleRunSimulator(24.5)}
            className="bg-emerald-600/90 hover:bg-emerald-500 text-white font-semibold text-xs px-3.5 py-2 rounded-lg transition shadow cursor-pointer flex items-center space-x-1.5"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Simulate Normal Speed (24.5 Mbps)</span>
          </button>
        </div>

        {testPayloadStatus && (
          <div className="p-3 bg-slate-900 border border-slate-700 rounded-lg text-xs font-mono text-cyan-300 mt-2">
            {testPayloadStatus}
          </div>
        )}
      </div>
    </div>
  );
};
