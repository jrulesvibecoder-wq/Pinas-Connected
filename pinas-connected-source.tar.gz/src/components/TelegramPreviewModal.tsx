import React, { useState } from 'react';
import { X, Send, Bot, CheckCheck, Smartphone, RefreshCw, Zap, Bell } from 'lucide-react';
import { Device, AppSettings } from '../types';

interface TelegramPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  devices: Device[];
  settings: AppSettings;
}

export const TelegramPreviewModal: React.FC<TelegramPreviewModalProps> = ({
  isOpen,
  onClose,
  devices,
  settings,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'speed' | 'billing' | 'recovered'>('speed');

  const selectedDevice = devices[0] || {
    name: 'a. lansob LiteBeam 5AC',
    clientName: 'Alejandro Lansob',
    throughput: 1.26,
    capacity: 22.62,
    signal: -64,
    txPower: 21,
    ip: '172.16.0.14',
    speedThreshold: 5.0,
    monthlyFee: 25.0,
    billingDueDay: 5,
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-[#18222D] border border-cyan-500/40 rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden text-gray-100 flex flex-col h-[650px] animate-in fade-in zoom-in-95 duration-150">
        {/* Phone Top Notch / Bar */}
        <div className="bg-[#17212B] px-4 py-3 flex items-center justify-between border-b border-gray-700/60 shrink-0">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-cyan-600 to-blue-500 flex items-center justify-center font-bold text-white shadow">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-sm text-white flex items-center space-x-1">
                <span>PTP LinkPulse Bot</span>
                <span className="text-[10px] bg-sky-900/60 text-sky-300 px-1 rounded">bot</span>
              </div>
              <div className="text-[10px] text-cyan-400">@PtpMonitorBot</div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Selector Tabs */}
        <div className="bg-[#0E1621] px-3 py-2 flex items-center justify-around text-xs border-b border-gray-800 shrink-0">
          <button
            onClick={() => setActiveTab('speed')}
            className={`px-2.5 py-1 rounded transition cursor-pointer ${
              activeTab === 'speed' ? 'bg-[#2B5278] text-white font-medium' : 'text-gray-400'
            }`}
          >
            Speed Drop (&lt;5M)
          </button>
          <button
            onClick={() => setActiveTab('recovered')}
            className={`px-2.5 py-1 rounded transition cursor-pointer ${
              activeTab === 'recovered' ? 'bg-[#2B5278] text-white font-medium' : 'text-gray-400'
            }`}
          >
            Recovered
          </button>
          <button
            onClick={() => setActiveTab('billing')}
            className={`px-2.5 py-1 rounded transition cursor-pointer ${
              activeTab === 'billing' ? 'bg-[#2B5278] text-white font-medium' : 'text-gray-400'
            }`}
          >
            Billing Reminder
          </button>
        </div>

        {/* Phone Chat Background */}
        <div className="flex-1 overflow-y-auto p-3 space-y-3 bg-[#0E1621] text-xs">
          <div className="text-center text-[10px] text-gray-500 my-1">Today</div>

          {/* Message 1: Bot Father Greeting */}
          <div className="flex items-start space-x-2">
            <div className="max-w-[85%] bg-[#182533] p-3 rounded-2xl rounded-tl-sm text-gray-200 shadow space-y-1">
              <div className="text-sky-300 font-semibold text-[11px]">PTP LinkPulse Monitor</div>
              <p className="text-[11px] text-gray-300">
                Bot initialized. Monitoring {devices.length} wireless links via Tailscale Funnel.
              </p>
              <div className="text-[9px] text-gray-500 text-right flex items-center justify-end space-x-1">
                <span>10:20 AM</span>
                <CheckCheck className="w-3 h-3 text-sky-400" />
              </div>
            </div>
          </div>

          {/* Active Message Preview based on Tab */}
          {activeTab === 'speed' && (
            <div className="flex items-start space-x-2 animate-in fade-in duration-200">
              <div className="max-w-[90%] bg-[#1F2C3A] border-l-4 border-amber-500 p-3 rounded-2xl rounded-tl-sm text-gray-200 shadow space-y-1.5">
                <div className="text-amber-400 font-bold text-xs flex items-center space-x-1">
                  <span>🚨 CRITICAL: Link Throughput Drop!</span>
                </div>
                <div className="text-[11px] space-y-1 font-mono text-gray-300">
                  <div>
                    📡 <b>Device:</b> {selectedDevice.name}
                  </div>
                  <div>
                    👤 <b>Client:</b> {selectedDevice.clientName}
                  </div>
                  <div className="text-amber-300 bg-amber-950/60 p-1 rounded">
                    📉 <b>Throughput:</b> {selectedDevice.throughput.toFixed(2)} Mbps
                    <br />
                    (Threshold: {selectedDevice.speedThreshold || settings.globalSpeedThreshold} Mbps)
                  </div>
                  <div>
                    📶 <b>Capacity:</b> {selectedDevice.capacity.toFixed(2)} Mbps
                  </div>
                  <div>
                    📶 <b>Signal:</b> {selectedDevice.signal} dBm | <b>TX:</b> {selectedDevice.txPower} dBm
                  </div>
                  <div>
                    📍 <b>IP:</b> {selectedDevice.ip}
                  </div>
                </div>
                <div className="text-[10px] text-amber-200/80 italic pt-1">
                  ⚠️ Speed is below 5.0 Mbps. Check link alignment, interference, or cabling.
                </div>
                <div className="text-[9px] text-gray-500 text-right flex items-center justify-end space-x-1">
                  <span>Just now</span>
                  <CheckCheck className="w-3 h-3 text-sky-400" />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'recovered' && (
            <div className="flex items-start space-x-2 animate-in fade-in duration-200">
              <div className="max-w-[90%] bg-[#1F2C3A] border-l-4 border-emerald-500 p-3 rounded-2xl rounded-tl-sm text-gray-200 shadow space-y-1.5">
                <div className="text-emerald-400 font-bold text-xs">
                  🟢 RECOVERED: Link Back to Normal
                </div>
                <div className="text-[11px] space-y-1 font-mono text-gray-300">
                  <div>
                    📡 <b>Device:</b> {selectedDevice.name}
                  </div>
                  <div>
                    👤 <b>Client:</b> {selectedDevice.clientName}
                  </div>
                  <div className="text-emerald-300 bg-emerald-950/60 p-1 rounded">
                    📈 <b>Throughput:</b> 18.50 Mbps (Normal)
                  </div>
                  <div>
                    📶 <b>Signal:</b> -58 dBm | <b>Latency:</b> 3ms
                  </div>
                </div>
                <div className="text-[9px] text-gray-500 text-right flex items-center justify-end space-x-1">
                  <span>Just now</span>
                  <CheckCheck className="w-3 h-3 text-sky-400" />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'billing' && (
            <div className="flex items-start space-x-2 animate-in fade-in duration-200">
              <div className="max-w-[95%] bg-[#1F2C3A] border-l-4 border-cyan-500 p-3 rounded-2xl rounded-tl-sm text-gray-200 shadow space-y-1.5">
                <div className="text-cyan-300 font-bold text-xs">
                  💳 CLIENT BILLING DUE REMINDER
                </div>
                <p className="text-[10px] text-gray-400">
                  Here is your client billing summary:
                </p>
                <div className="space-y-2 text-[10px] font-mono">
                  {devices.slice(0, 3).map((d) => (
                    <div key={d.id} className="bg-[#17212B] p-2 rounded border border-gray-700/60">
                      <div className="text-white font-bold">{d.clientName}</div>
                      <div className="text-gray-400">({d.name})</div>
                      <div className="text-cyan-300 mt-0.5">
                        📅 Due Day: <b>{d.billingDueDay}th</b> | Amount: <b>${d.monthlyFee.toFixed(2)}</b>
                      </div>
                      <div className="mt-0.5">
                        {d.paymentStatus === 'overdue' ? (
                          <span className="text-red-400 font-bold">🔴 OVERDUE</span>
                        ) : d.paymentStatus === 'pending' ? (
                          <span className="text-amber-400 font-bold">🟡 PENDING</span>
                        ) : (
                          <span className="text-emerald-400 font-bold">🟢 PAID</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="text-[9px] text-gray-500 text-right flex items-center justify-end space-x-1">
                  <span>10:22 AM</span>
                  <CheckCheck className="w-3 h-3 text-sky-400" />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Telegram Chat Input mockup */}
        <div className="bg-[#17212B] px-3 py-2.5 flex items-center space-x-2 border-t border-gray-700/60 shrink-0">
          <input
            type="text"
            readOnly
            value="Automatic telemetry from Tailscale Funnel"
            className="flex-1 bg-[#242F3D] text-[11px] text-gray-400 px-3 py-1.5 rounded-full outline-none"
          />
          <div className="w-8 h-8 rounded-full bg-cyan-600 flex items-center justify-center text-white">
            <Send className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>
    </div>
  );
};
