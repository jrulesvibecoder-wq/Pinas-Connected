import React, { useState } from 'react';
import { X, Copy, Check, Shield, Wifi, Terminal, ExternalLink } from 'lucide-react';
import { AppSettings } from '../types';

interface UispKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
}

export const UispKeyModal: React.FC<UispKeyModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  if (!isOpen) return null;

  const [copied, setCopied] = useState(false);
  const [managementEnabled, setManagementEnabled] = useState(true);
  const [funnelUrl, setFunnelUrl] = useState(settings.tailscaleFunnelUrl || 'https://ptp-monitor.tailscale.net');
  const [keyToken, setKeyToken] = useState(settings.uispKeyToken || 'uisp_lite_key_77a9b1c2');

  const generatedKey = `https://${funnelUrl.replace(/^https?:\/\//, '')}/api/telemetry?key=${keyToken}`;
  const airOsCompatibleKey = `wss://${funnelUrl.replace(/^https?:\/\//, '')}:443+${keyToken}+allowSelfSignedContract`;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    onUpdateSettings({
      tailscaleFunnelUrl: funnelUrl,
      uispKeyToken: keyToken,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      {/* Box styled directly based on airOS UISP dropdown from user's screenshot */}
      <div className="bg-[#1E293B] border border-cyan-500/40 rounded-xl shadow-2xl w-full max-w-lg overflow-hidden text-gray-100 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-[#0066CC] px-5 py-3.5 flex items-center justify-between text-white">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
            <span className="font-bold text-sm tracking-wider">UISP™ MANAGEMENT & KEY</span>
          </div>
          <button
            onClick={onClose}
            className="text-blue-100 hover:text-white p-1 rounded-md transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* UISP Management Toggle (Faithful to screenshot) */}
          <div className="flex items-center justify-between py-2 border-b border-gray-700/60">
            <div>
              <div className="text-xs font-semibold uppercase tracking-wider text-gray-300">
                UISP MANAGEMENT
              </div>
              <div className="text-xs text-gray-400">
                Allow remote antennas and CPEs to report throughput over Tailscale
              </div>
            </div>
            <button
              onClick={() => setManagementEnabled(!managementEnabled)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                managementEnabled ? 'bg-cyan-600' : 'bg-gray-600'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  managementEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Tailscale Funnel / Host URL */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-gray-300 flex items-center justify-between">
              <span>TAILSCALE FUNNEL DOMAIN / HOST</span>
              <span className="text-[10px] text-cyan-400 font-mono">e.g. your-node.ts.net</span>
            </label>
            <input
              type="text"
              value={funnelUrl}
              onChange={(e) => setFunnelUrl(e.target.value)}
              placeholder="https://your-node.ts.net or http://172.16.0.14:3000"
              className="w-full bg-[#0F172A] border border-gray-700 rounded-lg px-3 py-2 text-sm font-mono text-cyan-300 focus:outline-none focus:border-cyan-500"
            />
            <p className="text-[11px] text-gray-400">
              Run <code className="bg-gray-800 text-amber-300 px-1 py-0.5 rounded">tailscale funnel 3000</code> to get your public HTTPS URL without port forwarding!
            </p>
          </div>

          {/* UISP Key Display (exact field from user screenshot) */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-gray-300 flex items-center justify-between">
              <span>UISP KEY / TELEMETRY WEBHOOK</span>
              <span className="text-[10px] text-emerald-400">Copy to LiteBeam / airOS</span>
            </label>
            <div className="flex items-center bg-[#0F172A] border border-gray-700 rounded-lg p-2 space-x-2">
              <input
                type="text"
                readOnly
                value={airOsCompatibleKey}
                className="bg-transparent text-xs font-mono text-gray-200 flex-1 outline-none select-all overflow-ellipsis"
              />
              <button
                onClick={() => handleCopy(airOsCompatibleKey)}
                className="bg-cyan-600 hover:bg-cyan-500 text-white px-2.5 py-1 rounded text-xs flex items-center space-x-1 cursor-pointer transition shrink-0"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Key'}</span>
              </button>
            </div>
          </div>

          {/* HTTP Telemetry Endpoint (for Mikrotik / Linux curl) */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-gray-300 flex items-center justify-between">
              <span>HTTP POST REPORT URL (MIKROTIK / LINUX)</span>
            </label>
            <div className="flex items-center bg-[#0F172A] border border-gray-700 rounded-lg p-2 space-x-2">
              <input
                type="text"
                readOnly
                value={generatedKey}
                className="bg-transparent text-xs font-mono text-gray-200 flex-1 outline-none select-all overflow-ellipsis"
              />
              <button
                onClick={() => handleCopy(generatedKey)}
                className="bg-gray-700 hover:bg-gray-600 text-white px-2.5 py-1 rounded text-xs flex items-center space-x-1 cursor-pointer transition shrink-0"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copy URL</span>
              </button>
            </div>
          </div>

          {/* Quick instructions */}
          <div className="bg-cyan-950/40 border border-cyan-800/40 rounded-lg p-3 text-xs text-cyan-200 space-y-1.5">
            <div className="font-semibold text-cyan-300 flex items-center space-x-1.5">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span>How to link your LiteBeam 5AC:</span>
            </div>
            <p className="text-gray-300">
              1. Log into your Ubiquiti LiteBeam airOS web interface (e.g. <code>172.16.0.14</code>).<br />
              2. Open the <b>UISP</b> menu on the top right bar.<br />
              3. Turn UISP Management <b>ON</b>, paste this Key into <b>UISP KEY</b>, and click <b>Save / Add Key</b>.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-gray-900/80 px-6 py-3 flex items-center justify-end space-x-3 border-t border-gray-800">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs text-gray-400 hover:text-white transition cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-1.5 bg-[#0066CC] hover:bg-blue-600 text-white rounded-lg text-xs font-medium transition cursor-pointer shadow"
          >
            Save Configuration
          </button>
        </div>
      </div>
    </div>
  );
};
