import React from 'react';
import { X, Bell, CheckCircle2, AlertTriangle, Trash2, Calendar, Send, Activity } from 'lucide-react';
import { AlertLog } from '../types';

interface AlertLogDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  alerts: AlertLog[];
  onClearAlerts: () => void;
}

export const AlertLogDrawer: React.FC<AlertLogDrawerProps> = ({
  isOpen,
  onClose,
  alerts,
  onClearAlerts,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
      <div className="bg-[#0F172A] border-l border-slate-800 w-full max-w-md h-full shadow-2xl flex flex-col text-gray-100 animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 bg-[#0B132B] border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Bell className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-sm tracking-wide text-white">
              Alerts & Telegram Notifications
            </h3>
            <span className="bg-slate-800 text-cyan-300 text-xs px-2 py-0.5 rounded-full font-mono font-semibold">
              {alerts.length}
            </span>
          </div>

          <div className="flex items-center space-x-1">
            {alerts.length > 0 && (
              <button
                onClick={onClearAlerts}
                className="p-1.5 rounded-lg text-gray-400 hover:text-red-400 hover:bg-slate-800 transition cursor-pointer"
                title="Clear All Alerts"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {alerts.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center text-gray-500 space-y-2">
              <CheckCircle2 className="w-10 h-10 text-emerald-500/50" />
              <p className="text-sm">No alerts triggered yet.</p>
              <p className="text-xs text-gray-600 max-w-xs">
                When a wireless link drops below 5 Mbps or a client is due, notifications will appear here and in your Telegram!
              </p>
            </div>
          ) : (
            alerts.map((alert) => (
              <div
                key={alert.id}
                className={`p-3.5 rounded-xl border text-xs space-y-1.5 ${
                  alert.type === 'speed_drop'
                    ? 'bg-amber-950/20 border-amber-500/40 text-amber-200'
                    : alert.type === 'recovered'
                    ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-200'
                    : alert.type === 'billing_due'
                    ? 'bg-teal-950/20 border-teal-500/40 text-teal-200'
                    : 'bg-slate-900 border-slate-800 text-gray-300'
                }`}
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-semibold flex items-center space-x-1.5">
                    {alert.type === 'speed_drop' ? (
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                    ) : alert.type === 'recovered' ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    ) : alert.type === 'billing_due' ? (
                      <Calendar className="w-3.5 h-3.5 text-teal-400" />
                    ) : (
                      <Activity className="w-3.5 h-3.5 text-sky-400" />
                    )}
                    <span className="capitalize">{alert.type.replace('_', ' ')}</span>
                  </span>
                  <span className="text-gray-400 font-mono text-[10px]">
                    {new Date(alert.timestamp).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                      second: '2-digit',
                    })}
                  </span>
                </div>

                <p className="text-white text-xs leading-relaxed">{alert.message}</p>

                {alert.deviceName && (
                  <div className="text-[11px] text-gray-400">
                    Device: <span className="text-cyan-300">{alert.deviceName}</span>
                  </div>
                )}

                <div className="flex items-center justify-between pt-1 border-t border-slate-800/60 text-[10px]">
                  <span className="flex items-center space-x-1 text-gray-400">
                    <Send className="w-2.5 h-2.5 text-sky-400" />
                    <span>Telegram API:</span>
                  </span>
                  <span
                    className={`font-semibold ${
                      alert.delivered ? 'text-emerald-400' : 'text-amber-400'
                    }`}
                  >
                    {alert.delivered ? 'Dispatched' : 'Queued / In-App'}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
