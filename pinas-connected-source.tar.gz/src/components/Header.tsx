import React from 'react';
import { 
  Radio, 
  Send, 
  Calendar, 
  ShieldCheck, 
  Terminal, 
  Bell, 
  Plus, 
  Key, 
  ChevronDown,
  Activity,
  Server,
  Wallet,
  Users,
  User,
  Sparkles,
  Trash2,
  LifeBuoy
} from 'lucide-react';
import { AppSettings, Device, AlertLog, User as UserModel } from '../types';

interface HeaderProps {
  currentTab: 'devices' | 'speed' | 'billing' | 'telegram' | 'tailscale' | 'tickets' | 'admin';
  setCurrentTab: (tab: 'devices' | 'speed' | 'billing' | 'telegram' | 'tailscale' | 'tickets' | 'admin') => void;
  devices: Device[];
  alerts: AlertLog[];
  settings: AppSettings;
  currentUser: UserModel;
  openTicketCount?: number;
  onOpenUispKey: () => void;
  onOpenAddDevice: () => void;
  onOpenTelegramSettings: () => void;
  onOpenAlerts: () => void;
  onOpenDockerDeploy: () => void;
  onOpenSubscriptionModal: () => void;
  onOpenAuthModal: () => void;
  onClearAllDummies: () => void;
  onLoadSamples: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  devices,
  alerts,
  settings,
  currentUser,
  openTicketCount = 0,
  onOpenUispKey,
  onOpenAddDevice,
  onOpenTelegramSettings,
  onOpenAlerts,
  onOpenDockerDeploy,
  onOpenSubscriptionModal,
  onOpenAuthModal,
  onClearAllDummies,
  onLoadSamples,
}) => {
  const degradedCount = devices.filter(
    (d) => d.status === 'degraded' || d.throughput < (d.speedThreshold || settings.globalSpeedThreshold)
  ).length;
  const overdueCount = devices.filter((d) => d.paymentStatus === 'overdue' || d.paymentStatus === 'pending').length;

  const now = new Date().getTime();
  const expiry = new Date(currentUser.expiresAt).getTime();
  const trialEnd = new Date(currentUser.trialEndsAt).getTime();
  const daysLeft = Math.max(0, Math.ceil((expiry - now) / (1000 * 60 * 60 * 24)));
  const isTrial = now < trialEnd;
  const isAdmin = currentUser.role === 'admin';

  return (
    <header className="sticky top-0 z-30 bg-[#0B132B] border-b border-cyan-900/40 shadow-lg text-white">
      {/* Top Banner (Ubiquiti / UISP Inspired Style) */}
      <div className="bg-[#0066CC] px-4 py-2 flex flex-wrap items-center justify-between text-xs text-white shadow-inner gap-2">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1.5 font-bold tracking-wider text-sm">
            <Radio className="w-4 h-4 text-amber-300 animate-pulse" />
            <span className="tracking-widest font-black text-white">PINAS CONNECTED</span>
            <span className="bg-blue-800 text-[10px] px-1.5 py-0.5 rounded font-mono font-semibold text-cyan-200">WISP • PTP & PtMP</span>
          </div>

          <span className="hidden sm:inline-block text-blue-200">|</span>

          {/* Installer Profile / Switcher */}
          <button
            onClick={onOpenAuthModal}
            className="flex items-center space-x-1.5 bg-blue-700 hover:bg-blue-800 border border-blue-400/40 px-2 py-0.5 rounded text-[11px] transition cursor-pointer"
            title="Click to Switch User / Register"
          >
            <User className="w-3 h-3 text-cyan-200" />
            <span className="font-semibold text-white truncate max-w-[130px]">{currentUser.name}</span>
            <span className="text-[10px] bg-blue-900/90 px-1 py-0.2 rounded font-mono text-cyan-200">
              {isAdmin ? 'ADMIN' : 'INSTALLER'}
            </span>
          </button>
        </div>

        <div className="flex items-center space-x-2 sm:space-x-2.5">
          {/* 30-Day Subscription / Trial Status Pill */}
          {!isAdmin ? (
            <button
              onClick={onOpenSubscriptionModal}
              className={`flex items-center space-x-1 px-2.5 py-1 rounded text-xs font-semibold transition cursor-pointer shadow-sm ${
                currentUser.status === 'payment_pending_review'
                  ? 'bg-amber-950/80 border border-amber-400 text-amber-200 animate-pulse'
                  : isTrial
                  ? 'bg-indigo-900/80 hover:bg-indigo-800 border border-indigo-400/60 text-indigo-200'
                  : daysLeft <= 3
                  ? 'bg-red-950/80 border border-red-500 text-red-200'
                  : 'bg-emerald-950/80 border border-emerald-500 text-emerald-200'
              }`}
              title="Click to view subscription & wallet payment details"
            >
              <Wallet className="w-3.5 h-3.5" />
              <span>
                {currentUser.status === 'payment_pending_review'
                  ? 'Payment Pending'
                  : isTrial
                  ? `Trial: ${daysLeft}d Left`
                  : `${daysLeft}d Active`}
              </span>
            </button>
          ) : (
            <span className="bg-purple-900/90 text-purple-200 border border-purple-400/50 px-2 py-0.5 rounded text-[11px] font-mono font-semibold">
              Master Admin Mode
            </span>
          )}

          {/* Docker Deploy Modal Trigger */}
          <button
            onClick={onOpenDockerDeploy}
            className="flex items-center space-x-1 bg-slate-900/90 hover:bg-slate-800 border border-cyan-400/40 text-cyan-200 px-2.5 py-1 rounded text-xs transition cursor-pointer"
            title="Deploy via Docker with 1 command"
          >
            <Server className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline font-mono">Docker Deploy</span>
          </button>

          {/* UISP Key Trigger matching User's screenshot */}
          <button
            onClick={onOpenUispKey}
            className="flex items-center space-x-1.5 bg-blue-700 hover:bg-blue-800 border border-blue-400/40 px-2.5 py-1 rounded shadow-sm text-xs font-medium transition cursor-pointer"
            title="Configure UISP Key & Tailscale Funnel"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-sm animate-ping"></span>
            <span className="font-semibold tracking-wider">UISP™ KEY</span>
            <ChevronDown className="w-3 h-3 text-blue-200" />
          </button>

          {/* Quick Telegram Bot Status */}
          <button
            onClick={onOpenTelegramSettings}
            className={`flex items-center space-x-1 px-2.5 py-1 rounded border text-xs transition cursor-pointer ${
              settings.telegramToken && settings.telegramChatId
                ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-300'
                : 'bg-amber-950/70 border-amber-500/50 text-amber-300'
            }`}
            title="Telegram Bot Configuration"
          >
            <Send className="w-3 h-3" />
            <span className="hidden md:inline font-mono">
              {settings.telegramToken && settings.telegramChatId ? 'Bot Connected' : 'Setup Bot'}
            </span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex flex-wrap items-center justify-between gap-3">
        {/* Navigation Tabs */}
        <nav className="flex items-center space-x-1 sm:space-x-2 overflow-x-auto py-1">
          <button
            onClick={() => setCurrentTab('devices')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition cursor-pointer ${
              currentTab === 'devices'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-gray-300 hover:text-white hover:bg-gray-800/60'
            }`}
          >
            <Radio className="w-4 h-4 text-cyan-400" />
            <span>P2P & PtMP Links ({devices.length})</span>
          </button>

          <button
            onClick={() => setCurrentTab('speed')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition cursor-pointer ${
              currentTab === 'speed'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-gray-300 hover:text-white hover:bg-gray-800/60'
            }`}
          >
            <Activity className="w-4 h-4 text-amber-400" />
            <span>Speed Drops</span>
            {degradedCount > 0 && (
              <span className="bg-red-500 text-white font-mono text-[10px] px-1.5 py-0.2 rounded-full font-bold animate-pulse">
                {degradedCount} &lt;{settings.globalSpeedThreshold}M
              </span>
            )}
          </button>

          <button
            onClick={() => setCurrentTab('billing')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition cursor-pointer ${
              currentTab === 'billing'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-gray-300 hover:text-white hover:bg-gray-800/60'
            }`}
          >
            <Calendar className="w-4 h-4 text-emerald-400" />
            <span>Client Due Dates</span>
            {overdueCount > 0 && (
              <span className="bg-amber-500/90 text-black font-mono text-[10px] px-1.5 py-0.2 rounded-full font-bold">
                {overdueCount} Due
              </span>
            )}
          </button>

          {/* Support Tickets Tab */}
          <button
            onClick={() => setCurrentTab('tickets')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition cursor-pointer ${
              currentTab === 'tickets'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                : 'text-gray-300 hover:text-white hover:bg-gray-800/60'
            }`}
          >
            <LifeBuoy className="w-4 h-4 text-rose-400" />
            <span>Support Tickets</span>
            {openTicketCount > 0 && (
              <span className="bg-rose-500 text-white font-mono text-[10px] px-1.5 py-0.2 rounded-full font-bold animate-pulse">
                {openTicketCount}
              </span>
            )}
          </button>

          {/* Tailscale Linking Front-End */}
          <button
            onClick={() => setCurrentTab('tailscale')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition cursor-pointer ${
              currentTab === 'tailscale'
                ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                : 'text-gray-300 hover:text-white hover:bg-gray-800/60'
            }`}
          >
            <Terminal className="w-4 h-4 text-indigo-400" />
            <span>Tailscale Linking</span>
          </button>

          <button
            onClick={() => setCurrentTab('telegram')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition cursor-pointer ${
              currentTab === 'telegram'
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 shadow-sm'
                : 'text-gray-300 hover:text-white hover:bg-gray-800/60'
            }`}
          >
            <Send className="w-4 h-4 text-sky-400" />
            <span>Telegram Bot</span>
          </button>

          {/* Admin Control Tab */}
          {(isAdmin || currentUser.role === 'admin') && (
            <button
              onClick={() => setCurrentTab('admin')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition cursor-pointer ${
                currentTab === 'admin'
                  ? 'bg-purple-600/30 text-purple-300 border border-purple-500/50 shadow-sm'
                  : 'text-purple-300 hover:text-white hover:bg-purple-950/40'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-purple-400" />
              <span>Admin Control</span>
            </button>
          )}
        </nav>

        {/* Right side actions */}
        <div className="flex items-center space-x-2">
          {/* Quick Clean Up / Samples Dropdown */}
          <div className="flex items-center space-x-1">
            {devices.length > 0 ? (
              <button
                onClick={onClearAllDummies}
                className="text-[11px] text-gray-400 hover:text-amber-400 px-2 py-1 rounded hover:bg-slate-800 transition cursor-pointer flex items-center space-x-1"
                title="Wipe all links to start clean"
              >
                <Trash2 className="w-3 h-3" />
                <span className="hidden lg:inline">Clean Links</span>
              </button>
            ) : (
              <button
                onClick={onLoadSamples}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 px-2 py-1 rounded bg-slate-800/60 hover:bg-slate-800 transition cursor-pointer flex items-center space-x-1"
                title="Load sample Ubiquiti/Mikrotik templates"
              >
                <Sparkles className="w-3 h-3" />
                <span>Load Sample Links</span>
              </button>
            )}
          </div>

          {/* Alerts Bell */}
          <button
            onClick={onOpenAlerts}
            className="relative p-2 rounded-lg bg-gray-800/70 hover:bg-gray-700/80 text-gray-200 border border-gray-700 transition cursor-pointer"
            title="View Alert History"
          >
            <Bell className="w-4 h-4" />
            {alerts.length > 0 && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-[#0B132B]"></span>
            )}
          </button>

          {/* Add Device Button */}
          <button
            onClick={onOpenAddDevice}
            className="flex items-center space-x-1.5 bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs px-3 py-2 rounded-lg shadow-md transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Add P2P / PtMP Link</span>
          </button>
        </div>
      </div>
    </header>
  );
};
