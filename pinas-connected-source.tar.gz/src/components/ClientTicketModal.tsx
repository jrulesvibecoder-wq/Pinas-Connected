import React, { useState } from 'react';
import { 
  X, 
  LifeBuoy, 
  Send, 
  AlertTriangle, 
  User, 
  Phone, 
  Radio, 
  CheckCircle2 
} from 'lucide-react';
import { Device, Ticket } from '../types';

interface ClientTicketModalProps {
  isOpen: boolean;
  onClose: () => void;
  devices: Device[];
  installerId: string;
  onTicketCreated: (ticket: Ticket) => void;
  showToast: (text: string, type?: 'success' | 'alert' | 'info') => void;
}

export const ClientTicketModal: React.FC<ClientTicketModalProps> = ({
  isOpen,
  onClose,
  devices,
  installerId,
  onTicketCreated,
  showToast,
}) => {
  const [clientName, setClientName] = useState('');
  const [clientContact, setClientContact] = useState('');
  const [selectedDeviceId, setSelectedDeviceId] = useState('');
  const [category, setCategory] = useState<Ticket['category']>('no_internet');
  const [priority, setPriority] = useState<Ticket['priority']>('high');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  // Auto-fill client name when selecting a device
  const handleSelectDevice = (devId: string) => {
    setSelectedDeviceId(devId);
    const dev = devices.find((d) => d.id === devId);
    if (dev) {
      if (!clientName) setClientName(dev.clientName);
      if (!title) setTitle(`Connection Issue: ${dev.name}`);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName.trim() || !title.trim() || !description.trim()) {
      showToast('Client Name, Title, and Description are required', 'alert');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          installerId,
          deviceId: selectedDeviceId || undefined,
          clientName: clientName.trim(),
          clientContact: clientContact.trim(),
          title: title.trim(),
          description: description.trim(),
          category,
          priority,
        }),
      });

      const data = await res.json();
      if (data.success && data.ticket) {
        showToast(`Ticket #${data.ticket.ticketNumber} filed! Telegram alert sent to installer.`, 'success');
        onTicketCreated(data.ticket);
        onClose();
        // Reset
        setClientName('');
        setClientContact('');
        setSelectedDeviceId('');
        setTitle('');
        setDescription('');
      } else {
        showToast(`Failed to file ticket: ${data.error}`, 'alert');
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'alert');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0F172A] border border-cyan-700/50 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-[#1E293B] px-6 py-4 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
              <LifeBuoy className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white tracking-wide">
                File Client Support Ticket
              </h3>
              <p className="text-xs text-gray-400">
                Dispatches instant notification to technician via Telegram Bot
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-slate-700 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 text-xs">
          {/* Quick Device Link */}
          <div>
            <label className="block text-gray-300 font-semibold mb-1">
              Select Client Link / Antenna (Optional)
            </label>
            <select
              value={selectedDeviceId}
              onChange={(e) => handleSelectDevice(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
            >
              <option value="">-- Manual Client Entry / No Specific Link --</option>
              {devices.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.clientName}) - {d.topology.toUpperCase()} [{d.status.toUpperCase()}]
                </option>
              ))}
            </select>
          </div>

          {/* Client Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-gray-300 font-semibold mb-1">
                Client Full Name <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Maria Santos"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="block text-gray-300 font-semibold mb-1">
                Contact Number / Email
              </label>
              <input
                type="text"
                placeholder="e.g. +63 917 111 2233"
                value={clientContact}
                onChange={(e) => setClientContact(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>
          </div>

          {/* Category & Priority */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-gray-300 font-semibold mb-1">Issue Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white"
              >
                <option value="no_internet">🔴 No Internet Connection / Offline</option>
                <option value="slow_speed">🟡 Slow Speed / Below Threshold</option>
                <option value="high_latency">🟠 High Latency / Lagging</option>
                <option value="physical_damage">⚠️ Antenna / Cable / POE Damage</option>
                <option value="billing">💳 Billing / Payment Dispute</option>
                <option value="other">💬 General Inquiry / Other</option>
              </select>
            </div>

            <div>
              <label className="block text-gray-300 font-semibold mb-1">Priority Level</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-semibold"
              >
                <option value="critical">🔥 CRITICAL (Immediate Dispatch)</option>
                <option value="high">🔴 HIGH (Urgent Customer)</option>
                <option value="medium">🟡 MEDIUM (Normal)</option>
                <option value="low">🟢 LOW (Minor)</option>
              </select>
            </div>
          </div>

          {/* Ticket Title */}
          <div>
            <label className="block text-gray-300 font-semibold mb-1">
              Issue Summary / Subject <span className="text-red-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Internet blinking since 10 AM storm"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-gray-300 font-semibold mb-1">
              Problem Description & Symptoms <span className="text-red-400">*</span>
            </label>
            <textarea
              required
              rows={3}
              placeholder="Describe symptoms: lights on POE adapter, weather conditions, error message..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold py-2.5 rounded-lg shadow-lg transition cursor-pointer flex items-center justify-center space-x-2 mt-2"
          >
            <Send className="w-4 h-4" />
            <span>{submitting ? 'Filing Ticket...' : 'File Support Ticket & Alert Technician'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
