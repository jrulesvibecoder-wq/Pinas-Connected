import React, { useState, useEffect } from 'react';
import { 
  X, 
  Wallet, 
  CreditCard, 
  QrCode, 
  Copy, 
  Check, 
  Clock, 
  CheckCircle2, 
  AlertTriangle,
  Building,
  Send,
  Sparkles
} from 'lucide-react';
import { User, BankingPortalConfig, PaymentSubmission } from '../types';

interface InstallerSubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onPaymentSubmitted: () => void;
  showToast: (text: string, type?: 'success' | 'alert' | 'info') => void;
}

export const InstallerSubscriptionModal: React.FC<InstallerSubscriptionModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onPaymentSubmitted,
  showToast,
}) => {
  const [bankingConfig, setBankingConfig] = useState<BankingPortalConfig | null>(null);
  const [myPayments, setMyPayments] = useState<PaymentSubmission[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<string>('GCash / QRPh');
  const [referenceNumber, setReferenceNumber] = useState<string>('');
  const [amount, setAmount] = useState<number>(15);
  const [notes, setNotes] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetch('/api/banking-portal')
        .then((r) => r.json())
        .then((data) => {
          if (data.bankingPortal) {
            setBankingConfig(data.bankingPortal);
            setAmount(data.bankingPortal.monthlyPrice || 15);
          }
        });

      fetch(`/api/payments/installer/${currentUser.id}`)
        .then((r) => r.json())
        .then((data) => {
          if (data.payments) setMyPayments(data.payments);
        });
    }
  }, [isOpen, currentUser.id]);

  if (!isOpen) return null;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const now = new Date().getTime();
  const expiry = new Date(currentUser.expiresAt).getTime();
  const trialEnd = new Date(currentUser.trialEndsAt).getTime();
  const daysLeft = Math.max(0, Math.ceil((expiry - now) / (1000 * 60 * 60 * 24)));
  const isTrial = now < trialEnd;
  const isExpired = now > expiry;
  const isPending = currentUser.status === 'payment_pending_review';

  const handleSubmitPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!referenceNumber.trim()) {
      showToast('Please enter your payment reference number', 'alert');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/payments/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          installerId: currentUser.id,
          paymentMethod,
          referenceNumber: referenceNumber.trim(),
          amount,
          currency: bankingConfig?.currency || 'USD',
          notes,
        }),
      });

      const data = await res.json();
      if (data.success) {
        showToast('Payment Reference submitted! Admin will activate your +30 days.', 'success');
        setReferenceNumber('');
        setNotes('');
        onPaymentSubmitted();
        // Refresh payments list
        const pRes = await fetch(`/api/payments/installer/${currentUser.id}`).then((r) => r.json());
        if (pRes.payments) setMyPayments(pRes.payments);
      } else {
        showToast(`Submission failed: ${data.error}`, 'alert');
      }
    } catch (e: any) {
      showToast(`Error: ${e.message}`, 'alert');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-[#0F172A] border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="bg-[#1E293B] px-6 py-4 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white tracking-wide flex items-center space-x-2">
                <span>Installer Subscription & 30-Day Wallet Activation</span>
              </h3>
              <p className="text-xs text-gray-400">
                {currentUser.companyName} ({currentUser.email})
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-slate-700 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Current Status Card */}
          <div
            className={`p-4 rounded-xl border flex flex-wrap items-center justify-between gap-3 ${
              isPending
                ? 'bg-amber-950/40 border-amber-500/50 text-amber-200'
                : isTrial
                ? 'bg-blue-950/40 border-blue-500/50 text-blue-200'
                : isExpired
                ? 'bg-red-950/40 border-red-500/50 text-red-200'
                : 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200'
            }`}
          >
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-lg bg-black/30">
                {isPending ? (
                  <Clock className="w-6 h-6 text-amber-400 animate-spin" />
                ) : isTrial ? (
                  <Sparkles className="w-6 h-6 text-blue-400" />
                ) : isExpired ? (
                  <AlertTriangle className="w-6 h-6 text-red-400" />
                ) : (
                  <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                )}
              </div>
              <div>
                <div className="text-xs uppercase tracking-wider font-bold">
                  {isPending
                    ? 'Payment Submitted • Verification in Progress'
                    : isTrial
                    ? 'First 30-Days Free Trial Active'
                    : isExpired
                    ? 'Subscription Expired'
                    : 'Active 30-Day Plan'}
                </div>
                <div className="text-sm font-semibold text-white">
                  {isTrial && <span>Enjoy full access! {daysLeft} days remaining in trial.</span>}
                  {isPending && <span>Your reference is with Admin. Account will activate for +30 days upon review.</span>}
                  {!isTrial && !isPending && (
                    <span>Valid until {new Date(currentUser.expiresAt).toLocaleDateString()} ({daysLeft} days remaining)</span>
                  )}
                </div>
              </div>
            </div>

            <div className="text-right">
              <div className="text-xl font-extrabold font-mono text-white">
                {daysLeft} <span className="text-xs font-normal text-gray-300">Days Left</span>
              </div>
              <div className="text-[11px] text-gray-400">
                Renew: ${bankingConfig?.monthlyPrice || 15} / 30 Days
              </div>
            </div>
          </div>

          {/* Section: Admin Banking & Wallet Channels */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-gray-200 uppercase tracking-wider flex items-center space-x-1.5">
              <QrCode className="w-4 h-4 text-purple-400" />
              <span>Step 1: Send Payment to Admin Wallet / QR / Bank</span>
            </h4>

            {bankingConfig?.generalInstructions && (
              <p className="text-xs text-gray-400 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                {bankingConfig.generalInstructions}
              </p>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* E-Wallets (GCash, Maya, etc.) */}
              {bankingConfig?.walletAccounts.map((w) => (
                <div key={w.id} className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-purple-300 flex items-center space-x-1">
                      <Wallet className="w-3.5 h-3.5 text-purple-400" />
                      <span>{w.walletName}</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopy(w.accountNumberOrAddress)}
                      className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center space-x-1 cursor-pointer bg-slate-800 px-2 py-0.5 rounded"
                    >
                      {copiedText === w.accountNumberOrAddress ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy #</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="text-xs text-gray-300">
                    <div>Name: <b className="text-white">{w.accountName}</b></div>
                    <div className="font-mono text-cyan-300 bg-slate-950 p-1 rounded mt-1">
                      {w.accountNumberOrAddress}
                    </div>
                  </div>

                  {w.qrCodeUrl && (
                    <div className="mt-1 bg-white p-1 rounded inline-block">
                      <img src={w.qrCodeUrl} alt="QR" className="w-20 h-20 object-contain" />
                    </div>
                  )}

                  {w.instructions && (
                    <div className="text-[10px] text-gray-400 italic">{w.instructions}</div>
                  )}
                </div>
              ))}

              {/* Direct Banks */}
              {bankingConfig?.bankAccounts.map((b) => (
                <div key={b.id} className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-cyan-300 flex items-center space-x-1">
                      <Building className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{b.bankName}</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopy(b.accountNumber)}
                      className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center space-x-1 cursor-pointer bg-slate-800 px-2 py-0.5 rounded"
                    >
                      {copiedText === b.accountNumber ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy #</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="text-xs text-gray-300">
                    <div>Account: <b className="text-white">{b.accountName}</b></div>
                    <div className="font-mono text-cyan-300 bg-slate-950 p-1 rounded mt-1">
                      {b.accountNumber}
                    </div>
                  </div>

                  {b.instructions && (
                    <div className="text-[10px] text-gray-400 italic">{b.instructions}</div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Section: Post Payment Reference Form */}
          <form onSubmit={handleSubmitPayment} className="bg-slate-900/80 border border-purple-500/30 rounded-xl p-4 space-y-4">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center space-x-1.5">
              <CreditCard className="w-4 h-4 text-purple-400" />
              <span>Step 2: Post Payment Reference to Activate Account (+30 Days)</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block text-gray-300 mb-1 font-semibold">Payment Method Used</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                >
                  <option value="GCash / QRPh">GCash / QRPh</option>
                  <option value="Maya / PayMaya">Maya / PayMaya</option>
                  <option value="Bank Transfer (BDO / UnionBank)">Bank Transfer</option>
                  <option value="USDT (TRC20)">USDT (TRC20)</option>
                  <option value="Other">Other Wallet</option>
                </select>
              </div>

              <div>
                <label className="block text-gray-300 mb-1 font-semibold">
                  Payment Reference Number / Ref # <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 10928472918 or REF-84920"
                  value={referenceNumber}
                  onChange={(e) => setReferenceNumber(e.target.value)}
                  className="w-full bg-slate-950 border border-purple-500/60 rounded-lg p-2 text-white font-mono font-bold focus:outline-none focus:ring-1 focus:ring-purple-400"
                />
              </div>

              <div>
                <label className="block text-gray-300 mb-1 font-semibold">Amount Paid</label>
                <div className="relative">
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white font-mono"
                  />
                  <span className="absolute right-3 top-2 text-xs text-gray-400 font-mono">
                    {bankingConfig?.currency || 'USD'}
                  </span>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-gray-300 mb-1 text-xs">Additional Note / Sender Name</label>
              <input
                type="text"
                placeholder="e.g. Sent via Juan's GCash at 2:30 PM"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white text-xs"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs py-2.5 rounded-lg shadow-lg transition cursor-pointer flex items-center justify-center space-x-2"
            >
              <Send className="w-4 h-4" />
              <span>{submitting ? 'Submitting Reference...' : 'Post Reference & Request 30-Day Activation'}</span>
            </button>
          </form>

          {/* Past Submissions History */}
          {myPayments.length > 0 && (
            <div className="space-y-2">
              <h5 className="text-[11px] uppercase font-bold text-gray-400">Payment Reference History</h5>
              <div className="divide-y divide-slate-800 border border-slate-800 rounded-xl overflow-hidden text-xs">
                {myPayments.map((p) => (
                  <div key={p.id} className="p-3 bg-slate-900/60 flex items-center justify-between">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-mono font-bold text-cyan-300">Ref: {p.referenceNumber}</span>
                        <span className="text-gray-400">({p.paymentMethod})</span>
                        <span className="font-mono text-emerald-400">${p.amount} {p.currency}</span>
                      </div>
                      <div className="text-[11px] text-gray-500 mt-0.5">
                        Submitted: {new Date(p.submittedAt).toLocaleDateString()}
                      </div>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        p.status === 'approved'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-600'
                          : p.status === 'pending'
                          ? 'bg-amber-950 text-amber-300 border border-amber-600'
                          : 'bg-red-950 text-red-300 border border-red-600'
                      }`}
                    >
                      {p.status === 'pending' ? 'Pending Admin Activation' : p.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
